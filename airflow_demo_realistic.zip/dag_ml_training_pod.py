
from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from datetime import datetime
from common_notify import get_notify_task

with DAG(
    dag_id="realistic_ml_training_pod",
    schedule_interval=None,
    start_date=datetime(2025, 6, 1),
    catchup=False,
    tags=["realistic", "ml", "k8s"],
) as dag:

    ml_training_pod = KubernetesPodOperator(
        namespace='airflowpoc',
        image="python:3.8-slim",
        cmds=["python", "-c"],
        arguments=[
            "import time; print('Training model...'); time.sleep(20); print('Model trained.')"
        ],
        name="ml-training-pod",
        task_id="ml_training_task",
        is_delete_operator_pod=True,
        in_cluster=True,
        get_logs=True,
        schedulername="yunikorn"
    )

    notify_task = get_notify_task(dag)

    ml_training_pod >> notify_task
