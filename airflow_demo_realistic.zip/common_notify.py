
from airflow.operators.python import PythonOperator

def notify_success(context):
    dag_run = context.get('dag_run')
    dag_id = dag_run.dag_id if dag_run else 'unknown'
    message = f"✅ SUCCESS: DAG {dag_id} completed!"
    print(message)
    with open('/tmp/notifications.log', 'a') as f:
        f.write(f"{message}\n")

def get_notify_task(dag):
    return PythonOperator(
        task_id="notify_success",
        python_callable=notify_success,
        provide_context=True,
        dag=dag
    )
