
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import requests
import json
from common_notify import get_notify_task

def fetch_and_store_api_data():
    url = "https://api.exchangerate-api.com/v4/latest/USD"
    response = requests.get(url)
    data = response.json()
    
    with open('/tmp/exchange_rates.json', 'w') as f:
        json.dump(data, f)
    
    print("Exchange rate data fetched and stored.")

with DAG(
    dag_id="realistic_api_fetch",
    schedule_interval="@daily",
    start_date=datetime(2025, 6, 1),
    catchup=False,
    tags=["realistic", "api"],
) as dag:

    fetch_api_data = PythonOperator(
        task_id="fetch_and_store_api_data",
        python_callable=fetch_and_store_api_data
    )

    notify_task = get_notify_task(dag)

    fetch_api_data >> notify_task
