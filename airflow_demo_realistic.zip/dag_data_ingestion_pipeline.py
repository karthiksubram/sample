
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from datetime import datetime
import pandas as pd
from common_notify import get_notify_task

def process_csv():
    df = pd.read_csv('/tmp/sample.csv')
    df['processed'] = df['Height(Inches)'] * 2.54  # Convert inches to cm as example
    df.to_csv('/tmp/processed_sample.csv', index=False)
    print("CSV processed and saved.")

with DAG(
    dag_id="realistic_data_ingestion_pipeline",
    schedule_interval=None,
    start_date=datetime(2025, 6, 1),
    catchup=False,
    tags=["realistic", "data_pipeline"],
) as dag:

    download_csv = BashOperator(
        task_id="download_csv",
        bash_command="curl -o /tmp/sample.csv https://people.sc.fsu.edu/~jburkardt/data/csv/hw_200.csv"
    )

    process_csv_task = PythonOperator(
        task_id="process_csv",
        python_callable=process_csv
    )

    upload_csv = BashOperator(
        task_id="upload_csv",
        bash_command="mv /tmp/processed_sample.csv /tmp/final_output/ || mkdir -p /tmp/final_output && mv /tmp/processed_sample.csv /tmp/final_output/"
    )

    notify_task = get_notify_task(dag)

    download_csv >> process_csv_task >> upload_csv >> notify_task
