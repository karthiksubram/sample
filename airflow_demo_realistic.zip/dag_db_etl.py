
from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import sqlite3
from common_notify import get_notify_task

def etl():
    conn = sqlite3.connect('/tmp/example.db')
    cursor = conn.cursor()

    cursor.execute("CREATE TABLE IF NOT EXISTS source (id INT, value INT);")
    cursor.execute("INSERT INTO source (id, value) VALUES (1, 10), (2, 20);")
    conn.commit()

    rows = cursor.execute("SELECT * FROM source;").fetchall()
    transformed = [(row[0], row[1] * 100) for row in rows]

    cursor.execute("CREATE TABLE IF NOT EXISTS target (id INT, transformed_value INT);")
    cursor.executemany("INSERT INTO target (id, transformed_value) VALUES (?, ?);", transformed)
    conn.commit()

    print("ETL complete.")
    conn.close()

with DAG(
    dag_id="realistic_db_etl",
    schedule_interval=None,
    start_date=datetime(2025, 6, 1),
    catchup=False,
    tags=["realistic", "etl"],
) as dag:

    etl_task = PythonOperator(
        task_id="etl_task",
        python_callable=etl
    )

    notify_task = get_notify_task(dag)

    etl_task >> notify_task
