# Credit Exposure Migration — Multi-Agent Pipeline
## Powered by GitHub Copilot API | VS Code + IntelliJ Compatible

```
╔══════════════════════════════════════════════════════════╗
║  JS PFE/CVA/EE  +  SQL Server  →  Java + Spark + Iceberg ║
╚══════════════════════════════════════════════════════════╝
```

---

## Architecture

```
orchestrator.py
    │
    ├── agents/agent_repo.py       — Scans legacy repo, maps JS exposure functions & SQL objects
    ├── agents/agent_data.py       — SQL Server schema → Iceberg DDL + Spark ETL
    ├── agents/agent_exposure.py   — JS PFE/CVA/EE → Java 17 classes + JUnit parity tests
    └── agents/agent_validate.py   — Schema checks, JUnit runner, Copilot completeness review
    
    utils/
    ├── copilot_client.py          — GitHub Copilot API wrapper (OpenAI-compatible endpoint)
    ├── state.py                   — Shared migration state (persisted to state.json)
    └── logger.py                  — Colour-coded console logger
```

---

## Prerequisites

| Tool | Version | Purpose |
|---|---|---|
| Python | 3.10+ | Orchestrator runtime |
| GitHub Copilot | Enterprise / Business with Agents preview | LLM backend |
| `gh` CLI | Latest | Token resolution (optional) |
| Maven | 3.9+ | Run generated JUnit parity tests |
| Java | 17+ | Compile generated Java classes |

---

## Setup

### 1. Clone / copy this directory
```bash
cd migration_agents/
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Authenticate with GitHub Copilot

**Option A — environment variable (recommended for CI):**
```bash
export GITHUB_TOKEN=ghp_your_personal_access_token
```
Your PAT needs the `copilot` scope. Create at:
`GitHub → Settings → Developer settings → Personal access tokens → Fine-grained`

**Option B — GitHub CLI:**
```bash
gh auth login
# The agent will call `gh auth token` automatically
```

### 3. Verify Copilot access
```bash
python -c "from utils.copilot_client import CopilotClient; c = CopilotClient(); print(c.chat('You are helpful.', 'Say hello in one word.'))"
```

---

## Running the Pipeline

### Full pipeline (all 4 phases):
```bash
python orchestrator.py --repo-path /path/to/your/legacy-repo
```

### Individual phases:
```bash
# Phase 1: Scan repo, classify files, assess complexity
python orchestrator.py --repo-path /path/to/repo --phase repo

# Phase 2: Generate Iceberg DDL + Spark ETL from SQL Server schemas
python orchestrator.py --repo-path /path/to/repo --phase data

# Phase 3: Rewrite JS PFE/CVA/EE functions → Java 17
python orchestrator.py --repo-path /path/to/repo --phase exposure

# Phase 4: Validate parity, run JUnit, get Copilot sign-off
python orchestrator.py --repo-path /path/to/repo --phase validation
```

### Resume after interruption:
```bash
python orchestrator.py --repo-path /path/to/repo --resume
```

### Dry run (no Copilot API calls — print prompts only):
```bash
python orchestrator.py --repo-path /path/to/repo --dry-run
```

---

## Output Structure

```
migration_output/
├── state.json                              ← Shared agent state
│
├── repo_analysis/
│   ├── repo_analysis.json                  ← Full file/function/SQL inventory
│   └── risk_report.md                      ← Human-readable risk assessment
│
├── data_migration/
│   ├── schema_map.json                     ← SQL Server → Iceberg column mapping
│   ├── iceberg_tables.sql                  ← CREATE TABLE statements for Iceberg
│   ├── sql_server_to_iceberg_etl.py        ← Spark ETL job (ready to submit)
│   └── stored_proc_migration.md            ← Per-proc migration guidance
│
├── exposure_migration/
│   ├── migration_map.json                  ← JS function → Java class mapping
│   └── java/
│       ├── pom.xml                         ← Maven build file
│       └── src/
│           ├── main/java/com/migration/exposure/
│           │   ├── ExposureCalculation.java     ← Interface
│           │   ├── TradeInput.java              ← Shared input model
│           │   ├── PotentialFutureExposure.java ← Migrated PFE class
│           │   ├── ExpectedExposure.java        ← Migrated EE class
│           │   ├── CreditValuationAdjustment.java ← Migrated CVA class
│           │   └── spark/
│           │       └── ExposureCalculationSparkJob.java ← Spark batch job
│           └── test/java/com/migration/exposure/
│               ├── ParityTestHarness.java       ← PFE/CVA/EE parity tests
│               └── *Test.java                   ← Per-class JUnit tests
│
└── validation/
    ├── validation_report.md                ← Human sign-off report
    └── validation_report.json             ← Machine-readable results
```

---

## Running Generated Tests

```bash
cd migration_output/exposure_migration/java

# Compile and run all parity tests
mvn test

# Run only the parity harness
mvn test -Dtest=ParityTestHarness

# Run with verbose output
mvn test -Dsurefire.useFile=false
```

---

## Deploying the Spark Job on OpenShift (OCP)

```bash
# 1. Build the fat JAR
cd migration_output/exposure_migration/java
mvn package -DskipTests

# 2. Submit via Spark Operator on OCP
oc apply -f spark-application.yaml

# Or submit directly via spark-submit:
spark-submit \
  --master k8s://https://your-ocp-api:6443 \
  --deploy-mode cluster \
  --class com.migration.exposure.spark.ExposureCalculationSparkJob \
  --conf spark.kubernetes.container.image=your-registry/exposure-spark:latest \
  exposure-migration-1.0.0-SNAPSHOT.jar \
  --catalog-name  glue_catalog \
  --input-table   glue_catalog.credit_risk.trades \
  --output-table  glue_catalog.credit_risk.exposure_results \
  --calc-date     $(date +%Y-%m-%d)
```

---

## GitHub Copilot Agent Extension (VS Code / IntelliJ)

If your org has **Copilot Extensions (preview)** enabled, you can register this
pipeline as a `@migration-agent` extension for interactive use in the IDE:

1. Create `.github/copilot-extension.json` in your repo:
```json
{
  "name": "migration-agent",
  "description": "Credit exposure migration assistant",
  "commands": [
    {
      "name": "scan",
      "description": "Scan repo and classify exposure files",
      "script": "python orchestrator.py --repo-path . --phase repo"
    },
    {
      "name": "migrate-exposure",
      "description": "Rewrite JS PFE/CVA/EE to Java",
      "script": "python orchestrator.py --repo-path . --phase exposure"
    }
  ]
}
```
2. In Copilot Chat (VS Code): `@migration-agent /scan`
3. In Copilot Chat (IntelliJ): same syntax via the Copilot plugin chat window

---

## Numeric Parity Tolerance

All exposure calculations use `TOLERANCE = 1e-6` (one millionth).

For regulatory reporting you may need to tighten this. Edit in:
- `agents/agent_validate.py` → `TOLERANCE` constant
- `migration_output/exposure_migration/java/src/test/.../ParityTestHarness.java` → `TOLERANCE`

---

## Troubleshooting

| Error | Fix |
|---|---|
| `No GitHub token found` | Set `GITHUB_TOKEN` or run `gh auth login` |
| `Copilot API error 401` | Token lacks `copilot` scope — regenerate PAT |
| `Copilot API error 403` | Your org may not have Copilot API access enabled |
| `No exposure functions found` | JS files may use unusual naming — check `EXPOSURE_KEYWORDS` in `agent_repo.py` |
| `No SQL CREATE TABLE found` | SQL files use dynamic DDL — add table names manually to `schema_map.json` |
| `mvn not found` | Install Maven: `brew install maven` or `sdk install maven` |
