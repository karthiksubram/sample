"""
agents/agent_validate.py
------------------------
Validation Agent

Responsibilities:
  1. Run numeric parity checks between JS and Java exposure outputs
  2. Validate Iceberg schema against source SQL Server schema
  3. Run the JUnit parity test suite and parse results
  4. Produce a validation_report.json with pass/fail/tolerance metrics
"""

import json
import subprocess
import sys
from pathlib import Path

from utils.logger import AgentLogger
from utils.copilot_client import CopilotClient
from utils.state import MigrationState

TOLERANCE = 1e-6  # Numeric parity tolerance for all exposure values


class ValidationAgent:

    SYSTEM_PROMPT = """You are a senior QA engineer specialising in financial systems validation.
You validate numeric parity between legacy and migrated credit exposure systems.
You understand PFE, CVA, and EE calculations and acceptable tolerances.
Output only JSON or markdown as requested."""

    def __init__(
        self,
        repo_path: str,
        output_dir: Path,
        client: CopilotClient,
        state: MigrationState,
        exposure_result: dict,
        data_result: dict
    ):
        self.repo_path       = Path(repo_path)
        self.output_dir      = output_dir
        self.client          = client
        self.state           = state
        self.exposure_result = exposure_result
        self.data_result     = data_result
        self.log             = AgentLogger("Validation")
        self.output_dir.mkdir(parents=True, exist_ok=True)

    # ── Entry point ───────────────────────────────────────────────────────────
    def run(self) -> dict:
        self.log.info("Starting validation pipeline...")

        results = {}

        # 1. Schema parity check
        results["schema_validation"] = self._validate_schemas()

        # 2. Run JUnit tests if Maven is available
        results["junit_results"] = self._run_junit()

        # 3. Ask Copilot to review migration map for gaps
        results["copilot_review"] = self._copilot_review()

        # 4. Generate sign-off report
        self._write_validation_report(results)

        return results

    # ── Schema validation ─────────────────────────────────────────────────────
    def _validate_schemas(self) -> dict:
        self.log.info("Validating schema mapping...")
        sql_tables = self.data_result.get("sql_server_tables", [])
        table_schemas = self.data_result.get("table_schemas", {})

        issues = []
        for table, cols in table_schemas.items():
            for col in cols:
                if col["iceberg_type"] == "string" and col["sql_type"] not in (
                    "varchar", "nvarchar", "char", "nchar", "text", "ntext", "xml"
                ):
                    issues.append({
                        "table"  : table,
                        "column" : col["name"],
                        "issue"  : f"SQL type '{col['sql_type']}' mapped to string — verify",
                        "severity": "WARN"
                    })

        status = "PASS" if not issues else "WARN"
        self.log.info(f"Schema validation: {status} ({len(issues)} warnings)")
        return {"status": status, "issues": issues}

    # ── JUnit runner ──────────────────────────────────────────────────────────
    def _run_junit(self) -> dict:
        java_dir = self.exposure_result.get("java_dir") or \
                   str(self.state.get("exposure_migration_output_dir") or "")

        # Try to find pom.xml
        pom_candidates = [
            Path("migration_output/exposure_migration/java/pom.xml"),
        ]
        pom = next((p for p in pom_candidates if p.exists()), None)

        if not pom:
            self.log.warn("pom.xml not found — skipping JUnit execution.")
            return {
                "status" : "SKIPPED",
                "reason" : "pom.xml not found. Run: cd migration_output/exposure_migration/java && mvn test"
            }

        self.log.info(f"Running JUnit tests in {pom.parent}...")
        try:
            result = subprocess.run(
                ["mvn", "test", "-q"],
                cwd=str(pom.parent),
                capture_output=True, text=True, timeout=300
            )
            if result.returncode == 0:
                self.log.success("JUnit tests PASSED.")
                return {"status": "PASS", "output": result.stdout[-2000:]}
            else:
                self.log.warn("JUnit tests FAILED.")
                return {"status": "FAIL", "output": result.stdout[-2000:] + result.stderr[-1000:]}
        except FileNotFoundError:
            self.log.warn("mvn not found — skipping JUnit execution.")
            return {
                "status" : "SKIPPED",
                "reason" : "Maven not found on PATH. Install Maven to run parity tests."
            }
        except subprocess.TimeoutExpired:
            return {"status": "TIMEOUT", "reason": "Maven test run exceeded 5 minutes."}

    # ── Copilot gap review ────────────────────────────────────────────────────
    def _copilot_review(self) -> dict:
        self.log.info("Asking Copilot to review migration completeness...")
        migration_map = self.exposure_result.get("migration_map", [])
        failed        = self.exposure_result.get("failed", [])

        user_prompt = f"""
Review this credit exposure migration for completeness and risk.

Successfully migrated JS → Java functions:
{json.dumps(migration_map, indent=2)[:2000]}

Failed rewrites: {failed}

Schema tables migrated: {list(self.data_result.get('table_schemas', {}).keys())}

Return JSON:
{{
  "completeness_score": <0-100>,
  "critical_gaps": ["<gap1>", "<gap2>"],
  "pfe_coverage": "COMPLETE|PARTIAL|MISSING",
  "cva_coverage": "COMPLETE|PARTIAL|MISSING",
  "ee_coverage":  "COMPLETE|PARTIAL|MISSING",
  "recommended_next_steps": ["<step1>", "<step2>", "<step3>"],
  "go_live_ready": true|false,
  "go_live_blockers": ["<blocker1>"]
}}
"""
        try:
            return self.client.chat_json(self.SYSTEM_PROMPT, user_prompt)
        except Exception as e:
            self.log.warn(f"Copilot review failed: {e}")
            return {
                "completeness_score"    : 0,
                "critical_gaps"         : ["Could not assess — Copilot API unavailable"],
                "pfe_coverage"          : "UNKNOWN",
                "cva_coverage"          : "UNKNOWN",
                "ee_coverage"           : "UNKNOWN",
                "recommended_next_steps": ["Re-run with GITHUB_TOKEN set"],
                "go_live_ready"         : False,
                "go_live_blockers"      : ["Copilot API not available"]
            }

    # ── Validation report ─────────────────────────────────────────────────────
    def _write_validation_report(self, results: dict):
        schema  = results.get("schema_validation", {})
        junit   = results.get("junit_results", {})
        review  = results.get("copilot_review", {})

        ready = review.get("go_live_ready", False)
        score = review.get("completeness_score", "N/A")

        lines = [
            "# Migration Validation Report",
            "",
            f"## Overall Status: {'✅ GO-LIVE READY' if ready else '⚠️  NOT READY'}",
            f"## Completeness Score: {score}/100",
            "",
            "## Schema Validation",
            f"  Status: {schema.get('status', 'N/A')}",
            f"  Issues: {len(schema.get('issues', []))}",
        ]
        for issue in schema.get("issues", [])[:10]:
            lines.append(f"  - [{issue['severity']}] {issue['table']}.{issue['column']}: {issue['issue']}")

        lines += [
            "",
            "## JUnit Parity Tests",
            f"  Status: {junit.get('status', 'N/A')}",
        ]
        if junit.get("reason"):
            lines.append(f"  Note: {junit['reason']}")

        lines += [
            "",
            "## Exposure Coverage",
            f"  PFE: {review.get('pfe_coverage', 'UNKNOWN')}",
            f"  CVA: {review.get('cva_coverage', 'UNKNOWN')}",
            f"  EE : {review.get('ee_coverage',  'UNKNOWN')}",
            "",
            "## Critical Gaps",
        ]
        for gap in review.get("critical_gaps", []):
            lines.append(f"  - {gap}")

        lines += ["", "## Go-Live Blockers"]
        for b in review.get("go_live_blockers", []):
            lines.append(f"  - {b}")

        lines += ["", "## Next Steps"]
        for i, step in enumerate(review.get("recommended_next_steps", []), 1):
            lines.append(f"  {i}. {step}")

        out = self.output_dir / "validation_report.md"
        out.write_text("\n".join(lines))

        # Also save as JSON
        (self.output_dir / "validation_report.json").write_text(
            json.dumps(results, indent=2)
        )
        self.log.success(f"Validation report → {out}")
