"""
agents/agent_exposure.py
------------------------
Exposure Calculation Migration Agent

Responsibilities:
  1. Read each JS exposure function (PFE, CVA, EE) from the repo
  2. Ask Copilot to rewrite it as production-grade Java 17
  3. Generate JUnit 5 parity tests with numeric tolerance checks
  4. Produce Spark-ready Java wrappers for batch calculation
  5. Write a migration_map.json linking JS function → Java class
"""

import json
import re
from pathlib import Path
from typing import Optional

from utils.logger import AgentLogger
from utils.copilot_client import CopilotClient
from utils.state import MigrationState


class ExposureCalcAgent:

    SYSTEM_PROMPT = """You are a senior quant developer specialising in credit risk systems.
You migrate JavaScript PFE/CVA/EE exposure calculations to production-grade Java 17.
You write clean, well-commented Java with Apache Commons Math where needed.
You understand financial mathematics: Monte Carlo simulation, discount factors,
hazard rates, netting sets, and collateral agreements.
Output only the requested code or JSON — no prose."""

    def __init__(
        self,
        repo_path: str,
        output_dir: Path,
        client: CopilotClient,
        state: MigrationState,
        repo_analysis: dict
    ):
        self.repo_path     = Path(repo_path)
        self.output_dir    = output_dir
        self.client        = client
        self.state         = state
        self.repo_analysis = repo_analysis
        self.log           = AgentLogger("ExposureCalc")
        self.output_dir.mkdir(parents=True, exist_ok=True)
        (self.output_dir / "java" / "src" / "main" / "java" / "com" / "migration" / "exposure").mkdir(parents=True, exist_ok=True)
        (self.output_dir / "java" / "src" / "test" / "java" / "com" / "migration" / "exposure").mkdir(parents=True, exist_ok=True)

    # ── Entry point ───────────────────────────────────────────────────────────
    def run(self) -> dict:
        js_functions  = self.repo_analysis.get("js_functions", [])
        exposure_files = self.repo_analysis.get("exposure_files", [])

        self.log.info(f"Migrating {len(js_functions)} exposure functions from JS → Java")

        migration_map   = []
        failed_rewrites = []

        # Group functions by exposure type
        pfe_fns = [f for f in js_functions if self._classify(f) == "PFE"]
        cva_fns = [f for f in js_functions if self._classify(f) == "CVA"]
        ee_fns  = [f for f in js_functions if self._classify(f) == "EE"]
        other   = [f for f in js_functions if self._classify(f) == "OTHER"]

        self.log.info(f"Classified: PFE={len(pfe_fns)} CVA={len(cva_fns)} EE={len(ee_fns)} other={len(other)}")

        # Generate base scaffold classes (always generated, even without source functions)
        self._write_scaffold()

        # Rewrite each group
        for exposure_type, fns in [("PFE", pfe_fns), ("CVA", cva_fns), ("EE", ee_fns)]:
            if not fns:
                self.log.warn(f"No {exposure_type} functions found — generating template class.")
                self._write_template_class(exposure_type)
                continue

            for fn in fns:
                self.log.info(f"Rewriting {fn['function']} ({exposure_type})...")
                try:
                    result = self._rewrite_function(fn, exposure_type)
                    if result:
                        migration_map.append(result)
                except Exception as e:
                    self.log.warn(f"Failed to rewrite {fn['function']}: {e}")
                    failed_rewrites.append(fn["function"])

        # Generate parity test harness
        self._write_parity_test_harness(migration_map)

        # Generate Spark batch wrapper
        self._write_spark_wrapper(migration_map)

        # Write pom.xml
        self._write_pom()

        # Persist migration map
        out = self.output_dir / "migration_map.json"
        result = {
            "total_functions"   : len(js_functions),
            "migrated"          : len(migration_map),
            "failed"            : failed_rewrites,
            "migration_map"     : migration_map
        }
        out.write_text(json.dumps(result, indent=2))
        self.log.success(f"Migration map written → {out}")
        return result

    # ── Classify JS function by exposure type ─────────────────────────────────
    def _classify(self, fn: dict) -> str:
        name    = (fn.get("function") or "").lower()
        snippet = (fn.get("snippet")  or "").lower()
        combined = name + " " + snippet
        if any(k in combined for k in ["pfe", "potential_future", "potential future"]):
            return "PFE"
        if any(k in combined for k in ["cva", "credit_valuation", "credit valuation", "hazard"]):
            return "CVA"
        if any(k in combined for k in ["ee", "expected_exposure", "expected exposure", "epe"]):
            return "EE"
        return "OTHER"

    # ── Rewrite a single JS function to Java ─────────────────────────────────
    def _rewrite_function(self, fn: dict, exposure_type: str) -> Optional[dict]:
        # Read full file content if available
        full_source = ""
        try:
            full_path = self.repo_path / fn["file"]
            full_source = full_path.read_text(errors="ignore")
        except Exception:
            full_source = fn.get("snippet", "")

        class_name = self._to_class_name(fn["function"])

        user_prompt = f"""
Migrate this JavaScript {exposure_type} exposure calculation to Java 17.

JS Source file: {fn['file']}
JS Function name: {fn['function']}
JS Parameters: {fn['params']}

JS Source (full file or snippet):
```javascript
{full_source[:3000]}
```

Requirements:
1. Create a Java class named `{class_name}` in package `com.migration.exposure`
2. Preserve all mathematical logic exactly — numeric parity is critical
3. Use `double` for all financial calculations (no float)
4. Use Apache Commons Math (org.apache.commons:commons-math3) where helpful
5. Add Javadoc explaining what PFE/CVA/EE concept each method computes
6. Add a static `calculate(...)` method that mirrors the JS function signature
7. Handle edge cases: null inputs, zero notional, negative time
8. The class must be Spark-serializable (implement Serializable)

Return ONLY the complete Java class file content, no markdown fences.
"""
        java_code = self.client.chat(self.SYSTEM_PROMPT, user_prompt, max_tokens=2048)

        # Strip accidental fences
        java_code = self._strip_fences(java_code)

        # Write Java file
        java_dir = self.output_dir / "java" / "src" / "main" / "java" / "com" / "migration" / "exposure"
        java_file = java_dir / f"{class_name}.java"
        java_file.write_text(java_code)
        self.log.success(f"Written: {java_file.name}")

        # Generate JUnit test
        self._write_junit_test(fn, class_name, exposure_type, java_code)

        return {
            "js_function"    : fn["function"],
            "js_file"        : fn["file"],
            "exposure_type"  : exposure_type,
            "java_class"     : class_name,
            "java_file"      : str(java_file.relative_to(self.output_dir))
        }

    # ── JUnit 5 test generation ───────────────────────────────────────────────
    def _write_junit_test(self, fn: dict, class_name: str, exposure_type: str, java_code: str):
        user_prompt = f"""
Generate a JUnit 5 test class for this Java {exposure_type} calculation class.

Java class: {class_name}
Java code:
```java
{java_code[:2000]}
```

Requirements:
1. Test class named `{class_name}Test` in package `com.migration.exposure`
2. Use JUnit 5 (@Test, @ParameterizedTest where helpful)
3. Include tests for: typical trade, zero notional, negative time, boundary values
4. NUMERIC TOLERANCE: use assertEquals(expected, actual, 1e-6) for all doubles
5. Include a comment /* PARITY_CHECK */ above each assertion that validates
   the migrated value matches the legacy JS output
6. Add a @DisplayName describing what credit exposure scenario is tested

Return ONLY the complete Java test file, no markdown fences.
"""
        test_code = self.client.chat(self.SYSTEM_PROMPT, user_prompt, max_tokens=1500)
        test_code = self._strip_fences(test_code)

        test_dir = self.output_dir / "java" / "src" / "test" / "java" / "com" / "migration" / "exposure"
        test_file = test_dir / f"{class_name}Test.java"
        test_file.write_text(test_code)
        self.log.info(f"Test written: {test_file.name}")

    # ── Spark batch wrapper ───────────────────────────────────────────────────
    def _write_spark_wrapper(self, migration_map: list):
        self.log.info("Generating Spark batch wrapper...")
        class_refs = "\n".join(
            f"  // {m['exposure_type']}: {m['js_function']} → {m['java_class']}"
            for m in migration_map
        ) or "  // No functions migrated yet"

        spark_job = f"""package com.migration.exposure.spark;

import org.apache.spark.sql.*;
import org.apache.spark.sql.types.*;
import org.apache.spark.api.java.function.MapFunction;
import org.apache.iceberg.spark.SparkSessionCatalog;

import java.io.Serializable;

/**
 * ExposureCalculationSparkJob
 *
 * Runs PFE / CVA / EE calculations at portfolio scale using Apache Spark,
 * reading trade data from Apache Iceberg on S3 and writing results back.
 *
 * Migrated function mapping:
{class_refs}
 *
 * Usage:
 *   spark-submit --class com.migration.exposure.spark.ExposureCalculationSparkJob \\
 *     exposure-migration.jar \\
 *     --catalog-name  glue_catalog \\
 *     --input-table   glue_catalog.credit_risk.trades \\
 *     --output-table  glue_catalog.credit_risk.exposure_results \\
 *     --calc-date     2025-01-31
 */
public class ExposureCalculationSparkJob implements Serializable {{

    public static void main(String[] args) {{
        SparkSession spark = SparkSession.builder()
            .appName("CreditExposureCalculation")
            // Iceberg + Glue catalog config
            .config("spark.sql.extensions",
                "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
            .config("spark.sql.catalog.glue_catalog",
                "org.apache.iceberg.spark.SparkCatalog")
            .config("spark.sql.catalog.glue_catalog.catalog-impl",
                "org.apache.iceberg.aws.glue.GlueCatalog")
            .config("spark.sql.catalog.glue_catalog.warehouse",
                "s3://your-bucket/warehouse")
            .getOrCreate();

        ExposureCalculationSparkJob job = new ExposureCalculationSparkJob();
        job.run(spark, parseArgs(args));
        spark.stop();
    }}

    public void run(SparkSession spark, JobConfig config) {{
        // 1. Read trade positions from Iceberg
        Dataset<Row> trades = spark.read()
            .format("iceberg")
            .load(config.inputTable);

        // 2. Compute exposures using migrated Java classes
        Dataset<Row> exposures = trades.map(
            (MapFunction<Row, Row>) row -> computeExposure(row),
            ExposureResultEncoder.schema()
        );

        // 3. Write results to Iceberg output table (with partition overwrite)
        exposures.writeTo(config.outputTable)
            .option("write.format.default", "parquet")
            .overwritePartitions();

        System.out.printf("Exposure calculation complete. Rows written to %s%n",
            config.outputTable);
    }}

    private Row computeExposure(Row trade) {{
        // TODO: wire up migrated exposure classes here
        // Example:
        //   double pfe = PotentialFutureExposure.calculate(
        //       trade.getAs("notional"),
        //       trade.getAs("maturity_years"),
        //       trade.getAs("volatility")
        //   );
        //   double ee  = ExpectedExposure.calculate(...);
        //   double cva = CreditValuationAdjustment.calculate(pfe, ee, ...);
        throw new UnsupportedOperationException(
            "Wire up migrated exposure classes — see migration_map.json"
        );
    }}

    // ── Argument parsing ──────────────────────────────────────────────────
    static JobConfig parseArgs(String[] args) {{
        JobConfig cfg = new JobConfig();
        for (int i = 0; i < args.length - 1; i++) {{
            switch (args[i]) {{
                case "--catalog-name"  -> cfg.catalogName  = args[++i];
                case "--input-table"   -> cfg.inputTable   = args[++i];
                case "--output-table"  -> cfg.outputTable  = args[++i];
                case "--calc-date"     -> cfg.calcDate     = args[++i];
            }}
        }}
        return cfg;
    }}

    static class JobConfig {{
        String catalogName = "glue_catalog";
        String inputTable  = "glue_catalog.credit_risk.trades";
        String outputTable = "glue_catalog.credit_risk.exposure_results";
        String calcDate    = java.time.LocalDate.now().toString();
    }}

    /** Defines the Spark schema for exposure result rows. */
    static class ExposureResultEncoder {{
        static StructType schema() {{
            return new StructType()
                .add("trade_id",       DataTypes.StringType,  false)
                .add("counterparty_id",DataTypes.StringType,  false)
                .add("calc_date",      DataTypes.DateType,    false)
                .add("pfe",            DataTypes.DoubleType,  true)
                .add("ee",             DataTypes.DoubleType,  true)
                .add("cva",            DataTypes.DoubleType,  true)
                .add("currency",       DataTypes.StringType,  true);
        }}
    }}
}}
"""
        spark_dir = self.output_dir / "java" / "src" / "main" / "java" / "com" / "migration" / "exposure" / "spark"
        spark_dir.mkdir(parents=True, exist_ok=True)
        (spark_dir / "ExposureCalculationSparkJob.java").write_text(spark_job)
        self.log.success("Spark batch wrapper written.")

    # ── Scaffold: interfaces and shared model ─────────────────────────────────
    def _write_scaffold(self):
        base_dir = self.output_dir / "java" / "src" / "main" / "java" / "com" / "migration" / "exposure"

        # ExposureCalculation interface
        interface = """package com.migration.exposure;

import java.io.Serializable;

/**
 * Common interface for all migrated credit exposure calculations.
 * Implementations must be Spark-serializable.
 */
public interface ExposureCalculation extends Serializable {

    /**
     * Unique identifier for this calculation type (e.g. "PFE", "CVA", "EE").
     */
    String calculationType();

    /**
     * Currency in which results are expressed.
     */
    default String currency() { return "USD"; }
}
"""
        (base_dir / "ExposureCalculation.java").write_text(interface)

        # TradeInput model
        model = """package com.migration.exposure;

import java.io.Serializable;
import java.time.LocalDate;

/**
 * Input model representing a single trade for exposure calculation.
 * Maps from the Iceberg trades table schema.
 */
public record TradeInput(
    String      tradeId,
    String      counterpartyId,
    double      notional,
    String      currency,
    LocalDate   maturityDate,
    LocalDate   calcDate,
    double      marketValue,       // Current MTM
    double      volatility,        // Annualised vol
    double      creditSpread,      // Counterparty CDS spread (bps)
    double      recoveryRate,      // LGD = 1 - recoveryRate
    String      nettingSetId,
    double      collateralPosted
) implements Serializable {}
"""
        (base_dir / "TradeInput.java").write_text(model)
        self.log.info("Scaffold classes written.")

    # ── Template class for missing exposure types ─────────────────────────────
    def _write_template_class(self, exposure_type: str):
        class_name = {"PFE": "PotentialFutureExposure",
                      "CVA": "CreditValuationAdjustment",
                      "EE" : "ExpectedExposure"}.get(exposure_type, exposure_type)
        base_dir = self.output_dir / "java" / "src" / "main" / "java" / "com" / "migration" / "exposure"
        template = f"""package com.migration.exposure;

/**
 * {class_name}
 *
 * TODO: This is a generated template. Wire up the logic migrated from
 * your legacy JavaScript {exposure_type} calculation.
 *
 * @see migration_map.json for the source JS function mapping
 */
public class {class_name} implements ExposureCalculation {{

    @Override
    public String calculationType() {{ return "{exposure_type}"; }}

    /**
     * Calculate {exposure_type} for a single trade.
     *
     * @param trade  The trade input (notional, maturity, vol, etc.)
     * @return       {exposure_type} value in trade currency
     */
    public static double calculate(TradeInput trade) {{
        // TODO: migrate logic from legacy JavaScript
        throw new UnsupportedOperationException(
            "{class_name}.calculate() not yet implemented — see migration_map.json"
        );
    }}
}}
"""
        (base_dir / f"{class_name}.java").write_text(template)

    # ── Parity test harness ───────────────────────────────────────────────────
    def _write_parity_test_harness(self, migration_map: list):
        entries = "\n".join(
            f'    // {m["exposure_type"]}: {m["js_function"]} → {m["java_class"]}'
            for m in migration_map
        ) or "    // No functions migrated — add test cases here"

        harness = f"""package com.migration.exposure;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;

/**
 * ParityTestHarness
 *
 * Validates that migrated Java exposure calculations produce results
 * numerically equivalent to the legacy JavaScript implementations.
 *
 * TOLERANCE: 1e-6 (one millionth) — tighten if your risk system requires it.
 *
 * Run with: mvn test -Dtest=ParityTestHarness
 *
 * Migrated functions covered:
{entries}
 */
@DisplayName("JS → Java Parity Validation Suite")
public class ParityTestHarness {{

    static final double TOLERANCE = 1e-6;

    static TradeInput sampleTrade() {{
        return new TradeInput(
            "TRD-001",          // tradeId
            "CPTY-XYZ",         // counterpartyId
            10_000_000.0,       // notional
            "USD",              // currency
            LocalDate.of(2028, 6, 30), // maturityDate
            LocalDate.now(),    // calcDate
            250_000.0,          // marketValue (MTM)
            0.25,               // volatility (25%)
            150.0,              // creditSpread (150bps)
            0.40,               // recoveryRate (40%)
            "NET-001",          // nettingSetId
            500_000.0           // collateralPosted
        );
    }}

    @Test
    @DisplayName("PFE: Basic trade — value should be positive")
    void testPFE_basicTrade() {{
        TradeInput trade = sampleTrade();
        /* PARITY_CHECK: compare output with legacy JS pfe() result */
        double result = PotentialFutureExposure.calculate(trade);
        assertTrue(result >= 0, "PFE must be non-negative");
        // TODO: replace 0.0 with the actual JS output for this input
        // assertEquals(expectedFromJS, result, TOLERANCE);
    }}

    @Test
    @DisplayName("EE: Basic trade — value should be positive")
    void testEE_basicTrade() {{
        TradeInput trade = sampleTrade();
        /* PARITY_CHECK: compare output with legacy JS ee() result */
        double result = ExpectedExposure.calculate(trade);
        assertTrue(result >= 0, "EE must be non-negative");
    }}

    @Test
    @DisplayName("CVA: Basic trade — value should be positive")
    void testCVA_basicTrade() {{
        TradeInput trade = sampleTrade();
        /* PARITY_CHECK: compare output with legacy JS cva() result */
        double result = CreditValuationAdjustment.calculate(trade);
        assertTrue(result >= 0, "CVA must be non-negative");
    }}

    @Test
    @DisplayName("CVA: Zero notional should give zero CVA")
    void testCVA_zeroNotional() {{
        TradeInput trade = new TradeInput(
            "TRD-ZERO", "CPTY-XYZ", 0.0, "USD",
            LocalDate.of(2028, 6, 30), LocalDate.now(),
            0.0, 0.25, 150.0, 0.40, "NET-001", 0.0
        );
        /* PARITY_CHECK */
        double result = CreditValuationAdjustment.calculate(trade);
        assertEquals(0.0, result, TOLERANCE, "CVA should be 0 for zero notional");
    }}

    @Test
    @DisplayName("PFE: Fully collateralised trade should reduce exposure")
    void testPFE_fullyCollateralised() {{
        TradeInput uncollateralised = sampleTrade();
        TradeInput fullycollateralised = new TradeInput(
            "TRD-COLL", "CPTY-XYZ", 10_000_000.0, "USD",
            LocalDate.of(2028, 6, 30), LocalDate.now(),
            250_000.0, 0.25, 150.0, 0.40, "NET-001",
            10_000_000.0  // full collateral
        );
        double pfeFull  = PotentialFutureExposure.calculate(fullycollateralised);
        double pfeNone  = PotentialFutureExposure.calculate(uncollateralised);
        /* PARITY_CHECK */
        assertTrue(pfeFull <= pfeNone, "Full collateral should reduce PFE");
    }}
}}
"""
        test_dir = self.output_dir / "java" / "src" / "test" / "java" / "com" / "migration" / "exposure"
        (test_dir / "ParityTestHarness.java").write_text(harness)
        self.log.success("Parity test harness written.")

    # ── Maven pom.xml ─────────────────────────────────────────────────────────
    def _write_pom(self):
        pom = """<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0
                             http://maven.apache.org/xsd/maven-4.0.0.xsd">
  <modelVersion>4.0.0</modelVersion>

  <groupId>com.migration</groupId>
  <artifactId>exposure-migration</artifactId>
  <version>1.0.0-SNAPSHOT</version>
  <packaging>jar</packaging>

  <properties>
    <java.version>17</java.version>
    <maven.compiler.source>17</maven.compiler.source>
    <maven.compiler.target>17</maven.compiler.target>
    <spark.version>3.5.1</spark.version>
    <iceberg.version>1.5.2</iceberg.version>
    <junit.version>5.10.2</junit.version>
    <commons-math.version>3.6.1</commons-math.version>
  </properties>

  <dependencies>
    <!-- Apache Spark -->
    <dependency>
      <groupId>org.apache.spark</groupId>
      <artifactId>spark-core_2.12</artifactId>
      <version>${spark.version}</version>
      <scope>provided</scope>
    </dependency>
    <dependency>
      <groupId>org.apache.spark</groupId>
      <artifactId>spark-sql_2.12</artifactId>
      <version>${spark.version}</version>
      <scope>provided</scope>
    </dependency>

    <!-- Apache Iceberg -->
    <dependency>
      <groupId>org.apache.iceberg</groupId>
      <artifactId>iceberg-spark-runtime-3.5_2.12</artifactId>
      <version>${iceberg.version}</version>
    </dependency>
    <dependency>
      <groupId>org.apache.iceberg</groupId>
      <artifactId>iceberg-aws</artifactId>
      <version>${iceberg.version}</version>
    </dependency>

    <!-- Financial math -->
    <dependency>
      <groupId>org.apache.commons</groupId>
      <artifactId>commons-math3</artifactId>
      <version>${commons-math.version}</version>
    </dependency>

    <!-- Testing -->
    <dependency>
      <groupId>org.junit.jupiter</groupId>
      <artifactId>junit-jupiter</artifactId>
      <version>${junit.version}</version>
      <scope>test</scope>
    </dependency>
  </dependencies>

  <build>
    <plugins>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-shade-plugin</artifactId>
        <version>3.5.2</version>
        <executions>
          <execution>
            <phase>package</phase>
            <goals><goal>shade</goal></goals>
            <configuration>
              <createDependencyReducedPom>false</createDependencyReducedPom>
              <filters>
                <filter>
                  <artifact>*:*</artifact>
                  <excludes>
                    <exclude>META-INF/*.SF</exclude>
                    <exclude>META-INF/*.DSA</exclude>
                  </excludes>
                </filter>
              </filters>
            </configuration>
          </execution>
        </executions>
      </plugin>
      <plugin>
        <groupId>org.apache.maven.plugins</groupId>
        <artifactId>maven-surefire-plugin</artifactId>
        <version>3.2.5</version>
      </plugin>
    </plugins>
  </build>
</project>
"""
        (self.output_dir / "java" / "pom.xml").write_text(pom)
        self.log.info("pom.xml written.")

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _to_class_name(self, fn_name: str) -> str:
        """camelCase or snake_case JS name → PascalCase Java class name."""
        # Handle camelCase
        name = re.sub(r'([A-Z])', r'_\1', fn_name)
        # Split and title-case
        parts = re.split(r'[_\-\s]+', name)
        return "".join(p.title() for p in parts if p)

    def _strip_fences(self, code: str) -> str:
        code = code.strip()
        if code.startswith("```"):
            lines = code.split("\n")
            # Remove first and last fence lines
            lines = [l for l in lines if not l.strip().startswith("```")]
            code = "\n".join(lines)
        return code.strip()
