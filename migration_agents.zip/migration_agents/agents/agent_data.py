"""
agents/agent_data.py
--------------------
Data Migration Agent

Responsibilities:
  1. Map SQL Server tables → Apache Iceberg table DDL
  2. Generate Spark ETL jobs to extract from SQL Server and load to Iceberg on S3
  3. Produce schema_map.json for traceability
  4. Generate Iceberg partition strategies for exposure result tables
"""

import json
import re
from pathlib import Path
from typing import Optional

from utils.logger import AgentLogger
from utils.copilot_client import CopilotClient
from utils.state import MigrationState

# SQL Server → Iceberg type mapping
TYPE_MAP = {
    "int"              : "int",
    "bigint"           : "long",
    "smallint"         : "int",
    "tinyint"          : "int",
    "bit"              : "boolean",
    "decimal"          : "decimal(18,6)",
    "numeric"          : "decimal(18,6)",
    "money"            : "decimal(19,4)",
    "smallmoney"       : "decimal(10,4)",
    "float"            : "double",
    "real"             : "float",
    "datetime"         : "timestamp",
    "datetime2"        : "timestamp",
    "date"             : "date",
    "time"             : "string",
    "char"             : "string",
    "varchar"          : "string",
    "nvarchar"         : "string",
    "nchar"            : "string",
    "text"             : "string",
    "ntext"            : "string",
    "uniqueidentifier" : "uuid",
    "varbinary"        : "binary",
    "binary"           : "binary",
    "xml"              : "string",
}


class DataMigrationAgent:

    SYSTEM_PROMPT = """You are a senior data engineer specialising in migrating SQL Server data
to Apache Iceberg on S3 using Apache Spark.
You understand credit risk data models: trades, counterparties, netting sets,
exposure results, and regulatory capital tables.
Output only the requested code or JSON — no prose."""

    def __init__(
        self,
        repo_path: str,
        output_dir: Path,
        client: CopilotClient,
        state: MigrationState,
        repo_analysis: dict
    ):
        self.repo_path     = Path(repo_path)
        self.output_dir    = output_dir
        self.client        = client
        self.state         = state
        self.repo_analysis = repo_analysis
        self.log           = AgentLogger("DataMigration")
        self.output_dir.mkdir(parents=True, exist_ok=True)

    # ── Entry point ───────────────────────────────────────────────────────────
    def run(self) -> dict:
        sql_objects  = self.repo_analysis.get("sql_objects", {})
        sql_files    = [f for f in self.repo_analysis.get("exposure_files", [])
                        if f.endswith(".sql")]

        tables = sql_objects.get("tables", [])
        procs  = sql_objects.get("stored_procedures", [])
        views  = sql_objects.get("views", [])

        self.log.info(f"Mapping {len(tables)} tables, {len(procs)} procs, {len(views)} views")

        # Step 1: Parse SQL files for column definitions
        table_schemas = self._parse_table_schemas()

        # Step 2: Generate Iceberg DDL
        iceberg_ddl = self._generate_iceberg_ddl(table_schemas)

        # Step 3: Ask Copilot for partition strategy
        partition_strategy = self._get_partition_strategy(tables)

        # Step 4: Generate Spark ETL job
        self._write_spark_etl(table_schemas, partition_strategy)

        # Step 5: Write stored proc migration notes
        self._write_proc_migration_notes(procs)

        # Step 6: Write schema map
        schema_map = {
            "sql_server_tables" : tables,
            "table_schemas"     : table_schemas,
            "iceberg_ddl"       : iceberg_ddl,
            "partition_strategy": partition_strategy,
            "procedures_count"  : len(procs),
            "views_count"       : len(views),
        }
        out = self.output_dir / "schema_map.json"
        out.write_text(json.dumps(schema_map, indent=2))
        self.log.success(f"Schema map written → {out}")

        # Write Iceberg DDL file
        ddl_out = self.output_dir / "iceberg_tables.sql"
        ddl_out.write_text("\n\n".join(iceberg_ddl.values()))
        self.log.success(f"Iceberg DDL written → {ddl_out}")

        return schema_map

    # ── Parse SQL CREATE TABLE statements ─────────────────────────────────────
    def _parse_table_schemas(self) -> dict:
        """
        Walk all SQL files in the repo and extract CREATE TABLE column definitions.
        Returns: { "TableName": [{"name": ..., "sql_type": ..., "iceberg_type": ...}] }
        """
        col_pattern = re.compile(
            r'^\s*\[?(\w+)\]?\s+\[?(\w+)\]?'
            r'(?:\s*\(\d+(?:,\s*\d+)?\))?'
            r'(?:\s+(?:NOT\s+)?NULL)?',
            re.IGNORECASE
        )
        table_pattern = re.compile(
            r'CREATE\s+TABLE\s+(?:\[?\w+\]?\.)?\[?(\w+)\]?\s*\(([^;]+)',
            re.IGNORECASE | re.DOTALL
        )
        results = {}

        sql_files = list(self.repo_path.rglob("*.sql"))
        for fpath in sql_files:
            try:
                content = fpath.read_text(errors="ignore")
            except Exception:
                continue

            for m in table_pattern.finditer(content):
                table_name = m.group(1)
                body       = m.group(2)
                columns    = []
                for line in body.split("\n"):
                    line = line.strip().rstrip(",")
                    cm   = col_pattern.match(line)
                    if cm:
                        col_name  = cm.group(1)
                        sql_type  = cm.group(2).lower()
                        iceberg_t = TYPE_MAP.get(sql_type, "string")
                        # Skip constraint lines
                        if col_name.upper() in ("PRIMARY", "CONSTRAINT", "INDEX", "FOREIGN", "UNIQUE"):
                            continue
                        columns.append({
                            "name"         : col_name,
                            "sql_type"     : sql_type,
                            "iceberg_type" : iceberg_t
                        })
                if columns:
                    results[table_name] = columns

        if not results:
            self.log.warn("No SQL CREATE TABLE found — using credit risk template schemas.")
            results = self._credit_risk_template_schemas()

        return results

    # ── Iceberg DDL generation ────────────────────────────────────────────────
    def _generate_iceberg_ddl(self, table_schemas: dict) -> dict:
        ddl = {}
        for table, cols in table_schemas.items():
            col_defs = ",\n  ".join(
                f"`{c['name']}` {c['iceberg_type']}" for c in cols
            )
            ddl[table] = f"""-- Migrated from SQL Server: {table}
CREATE TABLE IF NOT EXISTS glue_catalog.credit_risk.{table.lower()} (
  {col_defs}
)
USING iceberg
PARTITIONED BY (months(calc_date))
TBLPROPERTIES (
  'write.format.default'    = 'parquet',
  'write.parquet.compression-codec' = 'snappy',
  'history.expire.min-snapshots-to-keep' = '5'
);"""
        return ddl

    # ── Partition strategy from Copilot ───────────────────────────────────────
    def _get_partition_strategy(self, tables: list) -> dict:
        self.log.info("Asking Copilot for Iceberg partition strategy...")
        user_prompt = f"""
Design an Apache Iceberg partition strategy for a credit exposure system.

Tables to partition: {tables}

Context:
- Data is credit exposure results: PFE, CVA, EE per trade per calculation date
- Query patterns: by calc_date, by counterparty_id, by netting_set_id
- Volume: ~10M rows/day, 5 years retention
- Engine: Apache Spark 3.5 on OpenShift

Return JSON:
{{
  "tables": {{
    "<table_name>": {{
      "partition_spec": "<iceberg partition spec>",
      "rationale": "<why>",
      "sort_order": "<optional sort>"
    }}
  }},
  "global_recommendations": ["<rec1>", "<rec2>"]
}}
"""
        try:
            return self.client.chat_json(self.SYSTEM_PROMPT, user_prompt)
        except Exception as e:
            self.log.warn(f"Partition strategy failed: {e} — using defaults.")
            return {
                "tables": {
                    t: {
                        "partition_spec": "months(calc_date)",
                        "rationale"     : "Default monthly partitioning on calc_date",
                        "sort_order"    : "counterparty_id, trade_id"
                    }
                    for t in tables
                },
                "global_recommendations": [
                    "Use months(calc_date) for all time-series tables",
                    "Add hidden partitioning on counterparty_id for point queries",
                    "Enable Iceberg metadata caching on Spark executors"
                ]
            }

    # ── Spark ETL job ─────────────────────────────────────────────────────────
    def _write_spark_etl(self, table_schemas: dict, partition_strategy: dict):
        table_list = list(table_schemas.keys())
        tables_str = ", ".join(f'"{t}"' for t in table_list)

        etl = f"""#!/usr/bin/env python3
\"\"\"
sql_server_to_iceberg_etl.py
-----------------------------
Spark ETL: Extract from SQL Server → Land in Apache Iceberg on S3

Usage:
    spark-submit sql_server_to_iceberg_etl.py \\
        --sql-server-host  your-server.database.windows.net \\
        --sql-server-db    CreditExposureDB \\
        --s3-warehouse     s3://your-bucket/warehouse \\
        --tables           trades,counterparties,exposure_results

Tables migrated: {', '.join(table_list) or 'see schema_map.json'}
\"\"\"

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
import argparse
import sys

TABLES = [{tables_str}]

SQL_SERVER_JDBC = (
    "jdbc:sqlserver://{{host}};databaseName={{db}};"
    "encrypt=true;trustServerCertificate=false;"
    "loginTimeout=30"
)

def build_spark(warehouse: str) -> SparkSession:
    return (
        SparkSession.builder
        .appName("SQLServer→Iceberg Migration ETL")
        .config("spark.sql.extensions",
                "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
        .config("spark.sql.catalog.glue_catalog",
                "org.apache.iceberg.spark.SparkCatalog")
        .config("spark.sql.catalog.glue_catalog.catalog-impl",
                "org.apache.iceberg.aws.glue.GlueCatalog")
        .config("spark.sql.catalog.glue_catalog.warehouse", warehouse)
        .config("spark.sql.catalog.glue_catalog.io-impl",
                "org.apache.iceberg.aws.s3.S3FileIO")
        .getOrCreate()
    )


def extract_table(spark, jdbc_url: str, jdbc_props: dict, table: str, calc_date: str):
    \"\"\"Extract a single table from SQL Server with predicate pushdown.\"\"\"
    print(f"[ETL] Extracting {{table}} for calc_date={{calc_date}}...")
    query = f"(SELECT * FROM {{table}} WHERE calc_date = '{{calc_date}}') AS t"
    df = (
        spark.read
        .jdbc(url=jdbc_url, table=query, properties=jdbc_props)
        # Add ETL metadata columns
        .withColumn("_etl_ts",   F.current_timestamp())
        .withColumn("_etl_src",  F.lit("sqlserver"))
    )
    print(f"[ETL] {{table}}: {{df.count()}} rows extracted.")
    return df


def load_iceberg(df, table: str, catalog: str = "glue_catalog"):
    \"\"\"Append-write extracted rows into the Iceberg table.\"\"\"
    target = f"{{catalog}}.credit_risk.{{table.lower()}}"
    print(f"[ETL] Loading → {{target}}")
    (
        df.writeTo(target)
        .option("write.format.default", "parquet")
        .append()
    )
    print(f"[ETL] Load complete → {{target}}")


def run(args):
    spark    = build_spark(args.s3_warehouse)
    jdbc_url = SQL_SERVER_JDBC.format(host=args.sql_server_host, db=args.sql_server_db)
    jdbc_props = {{
        "user"    : args.sql_user,
        "password": args.sql_password,
        "driver"  : "com.microsoft.sqlserver.jdbc.SQLServerDriver",
    }}

    tables = [t.strip() for t in args.tables.split(",")] if args.tables else TABLES

    for table in tables:
        try:
            df = extract_table(spark, jdbc_url, jdbc_props, table, args.calc_date)
            load_iceberg(df, table)
        except Exception as e:
            print(f"[ETL] ERROR on {{table}}: {{e}}", file=sys.stderr)
            if not args.skip_errors:
                raise

    spark.stop()
    print("[ETL] Pipeline complete.")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--sql-server-host", required=True)
    p.add_argument("--sql-server-db",   required=True)
    p.add_argument("--sql-user",        default="etl_user")
    p.add_argument("--sql-password",    required=True)
    p.add_argument("--s3-warehouse",    required=True)
    p.add_argument("--calc-date",       required=True, help="YYYY-MM-DD")
    p.add_argument("--tables",          default=None,  help="Comma-separated table list")
    p.add_argument("--skip-errors",     action="store_true")
    run(p.parse_args())
"""
        (self.output_dir / "sql_server_to_iceberg_etl.py").write_text(etl)
        self.log.success("Spark ETL script written.")

    # ── Stored proc migration notes ───────────────────────────────────────────
    def _write_proc_migration_notes(self, procs: list):
        if not procs:
            return
        lines = [
            "# Stored Procedure Migration Notes",
            "",
            "Each SQL Server stored procedure below must be reviewed and migrated",
            "to one of: Spark SQL, a Java service method, or a Spark UDF.",
            "",
            "| Procedure | Recommended Target | Notes |",
            "|---|---|---|",
        ]
        for proc in procs:
            name_lower = proc.lower()
            if any(k in name_lower for k in ["calc", "exposure", "pfe", "cva", "ee"]):
                target = "Java ExposureCalc class + Spark UDF"
                note   = "Core calculation — migrate to exposure agent output"
            elif any(k in name_lower for k in ["load", "insert", "upsert", "merge"]):
                target = "Spark ETL job"
                note   = "Data movement — replace with Iceberg MERGE INTO"
            elif any(k in name_lower for k in ["report", "summary", "agg"]):
                target = "Spark SQL view on Iceberg"
                note   = "Reporting — create Iceberg view"
            else:
                target = "TBD"
                note   = "Manual review required"
            lines.append(f"| `{proc}` | {target} | {note} |")

        (self.output_dir / "stored_proc_migration.md").write_text("\n".join(lines))
        self.log.info("Stored proc migration notes written.")

    # ── Fallback template schemas for credit risk ─────────────────────────────
    def _credit_risk_template_schemas(self) -> dict:
        return {
            "Trades": [
                {"name": "trade_id",       "sql_type": "varchar", "iceberg_type": "string"},
                {"name": "counterparty_id","sql_type": "varchar", "iceberg_type": "string"},
                {"name": "netting_set_id", "sql_type": "varchar", "iceberg_type": "string"},
                {"name": "notional",       "sql_type": "decimal", "iceberg_type": "decimal(18,6)"},
                {"name": "currency",       "sql_type": "char",    "iceberg_type": "string"},
                {"name": "maturity_date",  "sql_type": "date",    "iceberg_type": "date"},
                {"name": "market_value",   "sql_type": "decimal", "iceberg_type": "decimal(18,6)"},
                {"name": "calc_date",      "sql_type": "date",    "iceberg_type": "date"},
            ],
            "ExposureResults": [
                {"name": "trade_id",       "sql_type": "varchar", "iceberg_type": "string"},
                {"name": "counterparty_id","sql_type": "varchar", "iceberg_type": "string"},
                {"name": "calc_date",      "sql_type": "date",    "iceberg_type": "date"},
                {"name": "pfe",            "sql_type": "decimal", "iceberg_type": "decimal(18,6)"},
                {"name": "ee",             "sql_type": "decimal", "iceberg_type": "decimal(18,6)"},
                {"name": "cva",            "sql_type": "decimal", "iceberg_type": "decimal(18,6)"},
                {"name": "currency",       "sql_type": "char",    "iceberg_type": "string"},
            ],
            "Counterparties": [
                {"name": "counterparty_id","sql_type": "varchar", "iceberg_type": "string"},
                {"name": "name",           "sql_type": "nvarchar","iceberg_type": "string"},
                {"name": "credit_spread",  "sql_type": "decimal", "iceberg_type": "decimal(18,6)"},
                {"name": "recovery_rate",  "sql_type": "decimal", "iceberg_type": "decimal(18,6)"},
                {"name": "rating",         "sql_type": "varchar", "iceberg_type": "string"},
            ]
        }
