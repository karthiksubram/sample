"""
agents/agent_repo.py
--------------------
Repo Analyst Agent

Responsibilities:
  1. Walk the repo and classify files (JS exposure calc, SQL, Java, config)
  2. Extract JS function signatures related to PFE / CVA / EE
  3. Map SQL Server stored procedures and views
  4. Produce a structured repo_analysis.json used by downstream agents
"""

import ast
import json
import re
from pathlib import Path
from typing import Any

from utils.logger import AgentLogger
from utils.copilot_client import CopilotClient
from utils.state import MigrationState

# Keywords that indicate credit exposure computation in JS files
EXPOSURE_KEYWORDS = [
    "pfe", "cva", "ee", "ead", "lgd", "pd", "exposure",
    "counterparty", "netting", "collateral", "mtm", "marktomarket",
    "montecarlo", "simulation", "discount", "hazardrate", "creditspread",
    "potential_future", "expected_exposure"
]

SQL_EXTENSIONS  = {".sql"}
JS_EXTENSIONS   = {".js", ".mjs", ".ts"}
JAVA_EXTENSIONS = {".java"}
SKIP_DIRS       = {"node_modules", ".git", "dist", "build", "target", ".mvn", "__pycache__"}


class RepoAnalystAgent:

    SYSTEM_PROMPT = """You are a senior software architect specialising in credit risk systems migration.
You analyse legacy codebases and produce structured migration plans.
Your output is always precise JSON — no prose, no markdown."""

    def __init__(
        self,
        repo_path: str,
        output_dir: Path,
        client: CopilotClient,
        state: MigrationState
    ):
        self.repo_path  = Path(repo_path)
        self.output_dir = output_dir
        self.client     = client
        self.state      = state
        self.log        = AgentLogger("RepoAnalyst")
        self.output_dir.mkdir(parents=True, exist_ok=True)

    # ── Entry point ───────────────────────────────────────────────────────────
    def run(self) -> dict:
        self.log.info(f"Scanning repo: {self.repo_path}")

        js_files   = self._find_files(JS_EXTENSIONS)
        sql_files  = self._find_files(SQL_EXTENSIONS)
        java_files = self._find_files(JAVA_EXTENSIONS)

        self.log.info(f"Found: {len(js_files)} JS | {len(sql_files)} SQL | {len(java_files)} Java")

        # Step 1: Identify exposure JS files
        exposure_files = self._identify_exposure_files(js_files)
        self.log.info(f"Exposure-related JS files: {len(exposure_files)}")

        # Step 2: Extract JS function signatures
        js_functions = self._extract_js_functions(exposure_files)

        # Step 3: Extract SQL objects
        sql_objects = self._extract_sql_objects(sql_files)

        # Step 4: Map Java entry points
        java_services = self._extract_java_services(java_files)

        # Step 5: Ask Copilot to assess migration complexity
        complexity = self._assess_complexity(js_functions, sql_objects, java_services)

        analysis = {
            "repo_path"       : str(self.repo_path),
            "file_counts"     : {
                "js"  : len(js_files),
                "sql" : len(sql_files),
                "java": len(java_files)
            },
            "exposure_files"  : exposure_files,
            "js_functions"    : js_functions,
            "sql_objects"     : sql_objects,
            "java_services"   : java_services,
            "complexity"      : complexity
        }

        # Persist
        out = self.output_dir / "repo_analysis.json"
        out.write_text(json.dumps(analysis, indent=2))
        self.log.success(f"Repo analysis written → {out}")

        # Generate human-readable risk report
        self._write_risk_report(analysis)

        return analysis

    # ── File discovery ────────────────────────────────────────────────────────
    def _find_files(self, extensions: set) -> list[str]:
        results = []
        for p in self.repo_path.rglob("*"):
            if any(part in SKIP_DIRS for part in p.parts):
                continue
            if p.suffix.lower() in extensions:
                results.append(str(p))
        return results

    # ── Exposure file identification ──────────────────────────────────────────
    def _identify_exposure_files(self, js_files: list[str]) -> list[str]:
        exposure = []
        for fpath in js_files:
            try:
                content = Path(fpath).read_text(errors="ignore").lower()
                if any(kw in content for kw in EXPOSURE_KEYWORDS):
                    exposure.append(fpath)
            except Exception:
                pass
        return exposure

    # ── JS function extraction ────────────────────────────────────────────────
    def _extract_js_functions(self, exposure_files: list[str]) -> list[dict]:
        """
        Extract function names, parameters, and a snippet from each exposure JS file.
        Uses regex for broad JS/TS compatibility (no full AST parser dependency).
        """
        fn_pattern = re.compile(
            r'(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:function|\([^)]*\)\s*=>))'
            r'\s*\(([^)]*)\)',
            re.MULTILINE
        )
        results = []
        for fpath in exposure_files:
            try:
                content = Path(fpath).read_text(errors="ignore")
                for m in fn_pattern.finditer(content):
                    fn_name   = m.group(1) or m.group(2) or "anonymous"
                    fn_params = m.group(3).strip()
                    # Grab a few lines of context
                    start = max(0, m.start() - 20)
                    snippet = content[start : m.start() + 200].strip()
                    is_exposure = any(kw in fn_name.lower() or kw in snippet.lower()
                                      for kw in EXPOSURE_KEYWORDS)
                    if is_exposure:
                        results.append({
                            "file"    : str(Path(fpath).relative_to(self.repo_path)),
                            "function": fn_name,
                            "params"  : fn_params,
                            "snippet" : snippet[:300]
                        })
            except Exception:
                pass
        return results

    # ── SQL extraction ────────────────────────────────────────────────────────
    def _extract_sql_objects(self, sql_files: list[str]) -> dict:
        sp_pattern   = re.compile(r'CREATE\s+(?:OR\s+ALTER\s+)?PROCEDURE\s+(\S+)', re.I)
        view_pattern = re.compile(r'CREATE\s+(?:OR\s+ALTER\s+)?VIEW\s+(\S+)',      re.I)
        tbl_pattern  = re.compile(r'CREATE\s+TABLE\s+(\S+)',                        re.I)

        procedures, views, tables = [], [], []

        for fpath in sql_files:
            try:
                content = Path(fpath).read_text(errors="ignore")
                procedures += [m.group(1) for m in sp_pattern.finditer(content)]
                views      += [m.group(1) for m in view_pattern.finditer(content)]
                tables     += [m.group(1) for m in tbl_pattern.finditer(content)]
            except Exception:
                pass

        return {
            "stored_procedures": procedures,
            "views"            : views,
            "tables"           : tables
        }

    # ── Java service extraction ───────────────────────────────────────────────
    def _extract_java_services(self, java_files: list[str]) -> list[dict]:
        """Find Java classes that look like services or repositories."""
        class_pattern = re.compile(
            r'(?:@Service|@Repository|@Component|@RestController).*?'
            r'public\s+class\s+(\w+)',
            re.S
        )
        results = []
        for fpath in java_files[:200]:  # cap for large repos
            try:
                content = Path(fpath).read_text(errors="ignore")
                for m in class_pattern.finditer(content):
                    results.append({
                        "file" : str(Path(fpath).relative_to(self.repo_path)),
                        "class": m.group(1)
                    })
            except Exception:
                pass
        return results

    # ── Copilot complexity assessment ─────────────────────────────────────────
    def _assess_complexity(
        self,
        js_functions: list,
        sql_objects: dict,
        java_services: list
    ) -> dict:
        self.log.info("Asking Copilot to assess migration complexity...")

        user_prompt = f"""
Assess the migration complexity for this credit exposure system.

JS exposure functions found: {len(js_functions)}
Sample functions: {json.dumps(js_functions[:5], indent=2)}

SQL objects:
  Stored procedures: {len(sql_objects['stored_procedures'])}
  Views: {len(sql_objects['views'])}
  Tables: {len(sql_objects['tables'])}
  Sample procs: {sql_objects['stored_procedures'][:10]}

Java services: {len(java_services)}

Target stack: Java 17+, Apache Spark, Apache Iceberg, S3, OpenShift.

Return JSON with:
{{
  "overall_risk": "LOW|MEDIUM|HIGH|CRITICAL",
  "estimated_weeks": <integer>,
  "pfe_migration_complexity": "LOW|MEDIUM|HIGH",
  "cva_migration_complexity": "LOW|MEDIUM|HIGH",
  "ee_migration_complexity":  "LOW|MEDIUM|HIGH",
  "biggest_risks": ["<risk1>", "<risk2>", "<risk3>"],
  "recommended_order": ["<step1>", "<step2>", "<step3>"],
  "quick_wins": ["<win1>", "<win2>"]
}}
"""
        try:
            return self.client.chat_json(self.SYSTEM_PROMPT, user_prompt)
        except Exception as e:
            self.log.warn(f"Complexity assessment failed: {e} — using defaults.")
            return {
                "overall_risk"              : "MEDIUM",
                "estimated_weeks"           : 24,
                "pfe_migration_complexity"  : "HIGH",
                "cva_migration_complexity"  : "HIGH",
                "ee_migration_complexity"   : "MEDIUM",
                "biggest_risks"             : ["Stored procedure logic", "Numeric parity"],
                "recommended_order"         : ["Schema", "EE", "PFE", "CVA"],
                "quick_wins"                : ["Containerise Java app", "Land raw data in S3"]
            }

    # ── Risk report ───────────────────────────────────────────────────────────
    def _write_risk_report(self, analysis: dict):
        c = analysis["complexity"]
        lines = [
            "# Repo Analysis — Migration Risk Report",
            "",
            f"Overall Risk     : {c.get('overall_risk', 'UNKNOWN')}",
            f"Estimated Effort : {c.get('estimated_weeks', '?')} weeks",
            "",
            "## Exposure Complexity",
            f"  PFE : {c.get('pfe_migration_complexity')}",
            f"  CVA : {c.get('cva_migration_complexity')}",
            f"  EE  : {c.get('ee_migration_complexity')}",
            "",
            "## Top Risks",
        ]
        for r in c.get("biggest_risks", []):
            lines.append(f"  - {r}")
        lines += [
            "",
            "## Recommended Migration Order",
        ]
        for i, step in enumerate(c.get("recommended_order", []), 1):
            lines.append(f"  {i}. {step}")
        lines += ["", "## Quick Wins"]
        for w in c.get("quick_wins", []):
            lines.append(f"  - {w}")
        lines += [
            "",
            f"## File Counts",
            f"  JS   : {analysis['file_counts']['js']}",
            f"  SQL  : {analysis['file_counts']['sql']}",
            f"  Java : {analysis['file_counts']['java']}",
            "",
            f"## SQL Objects",
            f"  Stored Procedures : {len(analysis['sql_objects']['stored_procedures'])}",
            f"  Views             : {len(analysis['sql_objects']['views'])}",
            f"  Tables            : {len(analysis['sql_objects']['tables'])}",
        ]
        out = self.output_dir / "risk_report.md"
        out.write_text("\n".join(lines))
        self.log.success(f"Risk report written → {out}")
