"""
orchestrator.py
---------------
Main pipeline runner for the Credit Exposure Migration Multi-Agent System.
Coordinates all agents sequentially with shared state written to disk.

Usage:
    python orchestrator.py --repo-path /path/to/your/repo
    python orchestrator.py --repo-path /path/to/your/repo --phase data
    python orchestrator.py --repo-path /path/to/your/repo --phase exposure
"""

import argparse
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path

from agents.agent_repo     import RepoAnalystAgent
from agents.agent_data     import DataMigrationAgent
from agents.agent_exposure import ExposureCalcAgent
from agents.agent_validate import ValidationAgent
from utils.state           import MigrationState
from utils.logger          import AgentLogger
from utils.copilot_client  import CopilotClient

PHASES = ["repo", "data", "exposure", "validation"]

BANNER = """
╔══════════════════════════════════════════════════════════════╗
║     Credit Exposure Migration — Multi-Agent Pipeline         ║
║     Agents: Repo Analyst · Data · Exposure Calc · Validate   ║
║     LLM Backend: GitHub Copilot API                          ║
╚══════════════════════════════════════════════════════════════╝
"""


def parse_args():
    parser = argparse.ArgumentParser(
        description="Multi-agent migration pipeline for Credit Exposure systems"
    )
    parser.add_argument(
        "--repo-path", required=True,
        help="Path to the legacy repo root"
    )
    parser.add_argument(
        "--phase", default="all",
        choices=["all"] + PHASES,
        help="Run a specific phase only (default: all)"
    )
    parser.add_argument(
        "--output-dir", default="./migration_output",
        help="Directory to write all agent outputs"
    )
    parser.add_argument(
        "--resume", action="store_true",
        help="Resume from last saved state"
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="Print agent prompts without calling Copilot API"
    )
    return parser.parse_args()


def run_pipeline(args):
    print(BANNER)
    log = AgentLogger("Orchestrator")
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # ── State management ──────────────────────────────────────────────────────
    state = MigrationState(output_dir / "state.json")
    if args.resume and state.exists():
        log.info("Resuming from saved state...")
        state.load()
    else:
        state.init(repo_path=args.repo_path, started_at=datetime.now().isoformat())

    # ── Copilot client ────────────────────────────────────────────────────────
    client = CopilotClient(dry_run=args.dry_run)

    # ── Phase runner ──────────────────────────────────────────────────────────
    phases_to_run = PHASES if args.phase == "all" else [args.phase]

    for phase in phases_to_run:
        if state.is_phase_complete(phase):
            log.info(f"Phase [{phase}] already complete — skipping.")
            continue

        log.section(f"PHASE: {phase.upper()}")

        try:
            if phase == "repo":
                agent = RepoAnalystAgent(
                    repo_path=args.repo_path,
                    output_dir=output_dir / "repo_analysis",
                    client=client,
                    state=state
                )
                result = agent.run()
                state.set("repo_analysis", result)

            elif phase == "data":
                repo_analysis = state.get("repo_analysis")
                if not repo_analysis:
                    log.error("Repo analysis not found. Run 'repo' phase first.")
                    sys.exit(1)
                agent = DataMigrationAgent(
                    repo_path=args.repo_path,
                    output_dir=output_dir / "data_migration",
                    client=client,
                    state=state,
                    repo_analysis=repo_analysis
                )
                result = agent.run()
                state.set("data_migration", result)

            elif phase == "exposure":
                repo_analysis = state.get("repo_analysis")
                if not repo_analysis:
                    log.error("Repo analysis not found. Run 'repo' phase first.")
                    sys.exit(1)
                agent = ExposureCalcAgent(
                    repo_path=args.repo_path,
                    output_dir=output_dir / "exposure_migration",
                    client=client,
                    state=state,
                    repo_analysis=repo_analysis
                )
                result = agent.run()
                state.set("exposure_migration", result)

            elif phase == "validation":
                exposure_result = state.get("exposure_migration")
                data_result = state.get("data_migration")
                if not exposure_result:
                    log.error("Exposure migration not found. Run 'exposure' phase first.")
                    sys.exit(1)
                agent = ValidationAgent(
                    repo_path=args.repo_path,
                    output_dir=output_dir / "validation",
                    client=client,
                    state=state,
                    exposure_result=exposure_result,
                    data_result=data_result
                )
                result = agent.run()
                state.set("validation", result)

            state.mark_phase_complete(phase)
            log.success(f"Phase [{phase}] complete.")

        except KeyboardInterrupt:
            log.warn("Interrupted. State saved — use --resume to continue.")
            state.save()
            sys.exit(0)
        except Exception as e:
            log.error(f"Phase [{phase}] failed: {e}")
            state.save()
            raise

    # ── Final report ──────────────────────────────────────────────────────────
    state.set("completed_at", datetime.now().isoformat())
    state.save()

    log.section("MIGRATION PIPELINE COMPLETE")
    print_summary(state, output_dir, log)


def print_summary(state: "MigrationState", output_dir: Path, log: "AgentLogger"):
    log.info(f"Output directory : {output_dir.resolve()}")
    log.info(f"State file       : {output_dir / 'state.json'}")
    log.info("")
    log.info("Completed phases:")
    for phase in PHASES:
        status = "✅" if state.is_phase_complete(phase) else "⏭  skipped"
        log.info(f"  {status}  {phase}")
    log.info("")
    log.info("Key outputs:")
    for path in sorted(output_dir.rglob("*.json")) :
        log.info(f"  📄 {path.relative_to(output_dir)}")
    for path in sorted(output_dir.rglob("*.java")):
        log.info(f"  ☕ {path.relative_to(output_dir)}")
    for path in sorted(output_dir.rglob("*.yaml")):
        log.info(f"  📋 {path.relative_to(output_dir)}")


if __name__ == "__main__":
    args = parse_args()
    run_pipeline(args)
