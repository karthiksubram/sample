"""utils/state.py — Shared migration state persisted to disk."""
import json
from pathlib import Path


class MigrationState:
    def __init__(self, path: Path):
        self._path = path
        self._data: dict = {}

    def exists(self) -> bool:
        return self._path.exists()

    def init(self, **kwargs):
        self._data = {"phases_complete": [], **kwargs}
        self.save()

    def load(self):
        with open(self._path) as f:
            self._data = json.load(f)

    def save(self):
        self._path.parent.mkdir(parents=True, exist_ok=True)
        with open(self._path, "w") as f:
            json.dump(self._data, f, indent=2, default=str)

    def get(self, key: str):
        return self._data.get(key)

    def set(self, key: str, value):
        self._data[key] = value
        self.save()

    def is_phase_complete(self, phase: str) -> bool:
        return phase in self._data.get("phases_complete", [])

    def mark_phase_complete(self, phase: str):
        done = self._data.get("phases_complete", [])
        if phase not in done:
            done.append(phase)
        self._data["phases_complete"] = done
        self.save()
