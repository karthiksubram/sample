"""utils/logger.py — Colour-coded console logger for agents."""
import time

COLORS = {
    "reset":   "\033[0m",
    "bold":    "\033[1m",
    "cyan":    "\033[96m",
    "green":   "\033[92m",
    "yellow":  "\033[93m",
    "red":     "\033[91m",
    "magenta": "\033[95m",
    "dim":     "\033[2m",
}

AGENT_COLORS = {
    "Orchestrator"   : "magenta",
    "RepoAnalyst"    : "cyan",
    "DataMigration"  : "green",
    "ExposureCalc"   : "yellow",
    "Validation"     : "red",
    "CopilotClient"  : "dim",
}


class AgentLogger:
    def __init__(self, name: str):
        self.name  = name
        self.color = AGENT_COLORS.get(name, "cyan")

    def _prefix(self, level: str) -> str:
        c   = COLORS.get(self.color, "")
        rst = COLORS["reset"]
        ts  = time.strftime("%H:%M:%S")
        return f"{COLORS['dim']}{ts}{rst} {c}[{self.name}]{rst}"

    def info(self, msg: str):
        print(f"{self._prefix('INFO')}  {msg}")

    def success(self, msg: str):
        print(f"{self._prefix('OK')}  {COLORS['green']}✓ {msg}{COLORS['reset']}")

    def warn(self, msg: str):
        print(f"{self._prefix('WARN')} {COLORS['yellow']}⚠ {msg}{COLORS['reset']}")

    def error(self, msg: str):
        print(f"{self._prefix('ERR')}  {COLORS['red']}✗ {msg}{COLORS['reset']}")

    def section(self, title: str):
        bar = "─" * 60
        print(f"\n{COLORS['bold']}{bar}")
        print(f"  {title}")
        print(f"{bar}{COLORS['reset']}\n")
