"""
utils/copilot_client.py
-----------------------
Thin wrapper around the GitHub Copilot API (OpenAI-compatible endpoint).

GitHub Copilot exposes an OpenAI-compatible completions endpoint.
Auth token is read from:
  1. GITHUB_TOKEN env var  (preferred — use a PAT with copilot scope)
  2. gh auth token         (GitHub CLI fallback)

Copilot model IDs (as of 2025):
  gpt-4o              → default, best for code + reasoning
  gpt-4o-mini         → faster, cheaper for lightweight tasks
  claude-sonnet-4     → available if org has enabled Anthropic models in Copilot
  o3-mini             → reasoning-heavy tasks
"""

import os
import json
import subprocess
from typing import Optional
from utils.logger import AgentLogger

COPILOT_API_BASE = "https://api.githubcopilot.com"
DEFAULT_MODEL    = "gpt-4o"


class CopilotClient:
    def __init__(self, dry_run: bool = False, model: str = DEFAULT_MODEL):
        self.dry_run = dry_run
        self.model   = model
        self.log     = AgentLogger("CopilotClient")
        self.token   = self._resolve_token()

    # ── Token resolution ──────────────────────────────────────────────────────
    def _resolve_token(self) -> Optional[str]:
        token = os.environ.get("GITHUB_TOKEN")
        if token:
            self.log.info("Using GITHUB_TOKEN from environment.")
            return token
        try:
            result = subprocess.run(
                ["gh", "auth", "token"],
                capture_output=True, text=True, timeout=5
            )
            if result.returncode == 0:
                token = result.stdout.strip()
                self.log.info("Using token from `gh auth token`.")
                return token
        except FileNotFoundError:
            pass
        if not self.dry_run:
            raise EnvironmentError(
                "No GitHub token found. Set GITHUB_TOKEN or run `gh auth login`."
            )
        return None

    # ── Core chat method ──────────────────────────────────────────────────────
    def chat(
        self,
        system_prompt: str,
        user_prompt: str,
        max_tokens: int = 4096,
        temperature: float = 0.1,
        model: Optional[str] = None
    ) -> str:
        """
        Send a chat completion request to GitHub Copilot API.
        Returns the assistant message text.
        """
        import urllib.request
        import urllib.error

        model = model or self.model

        payload = {
            "model": model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "messages": [
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_prompt}
            ]
        }

        if self.dry_run:
            self.log.warn("[DRY RUN] Would call Copilot API with:")
            self.log.warn(f"  Model  : {model}")
            self.log.warn(f"  System : {system_prompt[:120]}...")
            self.log.warn(f"  User   : {user_prompt[:120]}...")
            return json.dumps({"dry_run": True, "model": model})

        url = f"{COPILOT_API_BASE}/chat/completions"
        headers = {
            "Authorization"       : f"Bearer {self.token}",
            "Content-Type"        : "application/json",
            "Copilot-Integration-Id": "migration-agent",
            "Editor-Version"      : "vscode/1.90.0",
        }

        req = urllib.request.Request(
            url,
            data=json.dumps(payload).encode(),
            headers=headers,
            method="POST"
        )

        try:
            with urllib.request.urlopen(req, timeout=120) as resp:
                data = json.loads(resp.read())
                return data["choices"][0]["message"]["content"]
        except urllib.error.HTTPError as e:
            body = e.read().decode()
            self.log.error(f"Copilot API error {e.code}: {body}")
            raise

    # ── Structured JSON output ────────────────────────────────────────────────
    def chat_json(
        self,
        system_prompt: str,
        user_prompt: str,
        **kwargs
    ) -> dict:
        """
        Like chat(), but instructs the model to return JSON and parses the result.
        """
        system_prompt += "\n\nIMPORTANT: Respond ONLY with valid JSON. No markdown, no explanation."
        raw = self.chat(system_prompt, user_prompt, **kwargs)

        if self.dry_run:
            return {"dry_run": True}

        # Strip accidental markdown fences
        raw = raw.strip()
        if raw.startswith("```"):
            raw = raw.split("```")[1]
            if raw.startswith("json"):
                raw = raw[4:]
        raw = raw.strip().rstrip("`").strip()

        try:
            return json.loads(raw)
        except json.JSONDecodeError as e:
            self.log.error(f"JSON parse error: {e}\nRaw response:\n{raw[:500]}")
            raise
