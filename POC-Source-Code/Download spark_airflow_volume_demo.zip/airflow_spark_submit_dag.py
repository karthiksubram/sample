from airflow import DAG
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import KubernetesPodOperator
from datetime import datetime

with DAG(
    dag_id='submit_sparkapplication_yaml',
    start_date=datetime(2023, 1, 1),
    schedule_interval=None,
    catchup=False
) as dag:

    submit_spark = KubernetesPodOperator(
        task_id='submit_spark_job',
        name='submit-spark-job',
        namespace='default',
        image='bitnami/kubectl:latest',
        cmds=["kubectl", "apply", "-f", "/mnt/spark/spark-app.yaml"],
        volumes=[{
            "name": "spark-yaml-volume",
            "persistentVolumeClaim": {"claimName": "spark-code-pvc"}
        }],
        volume_mounts=[{
            "name": "spark-yaml-volume",
            "mountPath": "/mnt/spark"
        }],
        get_logs=True,
        is_delete_operator_pod=True
    )
