from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("VolumeMountExample").getOrCreate()
data = spark.range(1, 100)
data.show()
spark.stop()
