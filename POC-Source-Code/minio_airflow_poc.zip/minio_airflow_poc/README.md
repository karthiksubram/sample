# MinIO Persistent Deployment in OCP Namespace `airflow`

## 1️⃣ Prerequisites

- Namespace `airflow` exists.
- You have `helm` CLI installed.
- You have access to OpenShift cluster.

## 2️⃣ Install MinIO Helm Chart

### Add MinIO repo:

```bash
helm repo add minio https://charts.min.io/
helm repo update
```

### Install MinIO:

```bash
helm install minio minio/minio   --namespace airflow   --create-namespace   -f values.yaml
```

## 3️⃣ Expose MinIO Console via Route

```bash
oc expose service minio -n airflow
oc get route minio -n airflow
```

### Access MinIO Console:

- Console → `https://<route>:9001`
- API → `https://<route>:9000`

## 4️⃣ Default Credentials

- Username: `minioadmin`
- Password: `minioadmin`

---

✅ You can use this MinIO instance to store Airflow DAG results, logs, or test S3 integration.