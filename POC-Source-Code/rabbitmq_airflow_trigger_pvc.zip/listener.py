import os
import json
import pika
import requests
from requests.auth import HTTPBasicAuth

def trigger_airflow_dag(dag_id, payload):
    airflow_url = os.getenv('AIRFLOW_API_URL', 'http://airflow-webserver:8080')
    dag_run_url = f"{airflow_url}/api/v1/dags/{dag_id}/dagRuns"

    response = requests.post(
        dag_run_url,
        json={"conf": payload},
        auth=HTTPBasicAuth(os.getenv('AIRFLOW_USER'), os.getenv('AIRFLOW_PASS'))
    )

    print(f"Triggered DAG {dag_id}, status: {response.status_code}")
    print(response.text)

rabbitmq_host = os.getenv('RABBITMQ_HOST', 'rabbitmq')

connection = pika.BlockingConnection(pika.ConnectionParameters(host=rabbitmq_host))
channel = connection.channel()

channel.queue_declare(queue='demo')

def callback(ch, method, properties, body):
    print(f" [x] Received {body}")
    trigger_airflow_dag("example_dag", {"message": body.decode()})

channel.basic_consume(queue='demo', on_message_callback=callback, auto_ack=True)

print(' [*] Waiting for messages. To exit press CTRL+C')
channel.start_consuming()
