# MinIO Persistent Deployment in OCP Namespace `airflow` (YAML Based)

## 1️⃣ Apply StatefulSet + Service + Route

```bash
oc apply -f minio-statefulset.yaml
oc apply -f minio-service.yaml
oc apply -f minio-route.yaml
```

## 2️⃣ Verify

```bash
oc get pods -n airflow
oc get svc minio -n airflow
oc get route minio -n airflow
```

## 3️⃣ Access MinIO Console

Use Route URL → `https://<route-url>` (port 9001)

## 4️⃣ Credentials

- Username: `minioadmin`
- Password: `minioadmin`

---

✅ This YAML is tuned for OpenShift → uses non-root user → works with restricted SCC.