# Agent 02 — Alt PFE Reader

**Phase:** 1 — Understand
**Purpose:** Read the entire Alt PFE legacy repo and produce a complete,
structured inventory of all 35 models. This JSON file is the single source
of truth that drives the entire migration.

---

## Inputs
```
altpfe-repo/                          ← read every source file, read-only
knowledge/tds-contract.md             ← must exist (run Agent 01 first)
```

## Output
```
knowledge/altpfe-model-inventory.json
```

---

## Instructions

### Step 1 — Find all 35 models

Locate the Autosys job definitions or scheduler entry points.
Every job that calls Alt PFE corresponds to one model.

```
@workspace find all autosys job configs, scheduler configs, or
           main entry point classes in altpfe-repo
```

For each model, identify:
- Model name — as used in the job name or config key
- Asset class — FX, IR, EQ, CR, CO, or other
- The main Java orchestrator class responsible for this model

Cross-check: there must be exactly 35 models. If you find fewer or more,
list what you found and flag `[ESCALATE]` before continuing.

### Step 2 — Per model: trace data loading

For each Java orchestrator class, read it fully. Extract:

1. Every TDS dataset load call — refer to `knowledge/tds-contract.md`
   for the method signatures
2. Filter parameters passed to each load (asset class, trade date,
   book, curve type — whatever is passed)
3. Any pre-processing applied to a dataset before it enters the join chain
   (filtering, column projections, derived columns added)

### Step 3 — Per model: trace the full join chain

Extract every join in execution order:

- Which two datasets are joined (left side, right side)
- TDS join method used — look up SQL equivalent from tds-contract.md
- Join key column(s)
- Any column renaming or projection applied after the join
- Final output dataset column set entering the JS invocation

### Step 4 — Per model: find the JS invocation

Locate the exact point where the JavaScript engine is called:

- JS file path (relative to altpfe-repo root)
- Parameter names and their source columns from the joined dataset
- Return value type (single double? array? named fields?)
- Any post-processing of the JS return value before writing output

### Step 5 — Per model: analyse the JS formula file

Read the JS file fully. Extract:

- Line count (`js_lines`) — count non-blank, non-comment lines
- All input variable names and their expected types
- Plain-English description of the calculation (3–5 sentences —
  enough for a reviewer to understand the business logic)
- Complexity signals:
  - `dynamic_eval` — does it use `eval()` or `new Function()`?
  - `external_calls` — does it call anything outside its own scope?
  - `date_arithmetic` — does it manipulate dates?
  - `if_count` — how many `if` / `else if` / ternary branches?
  - `has_loops` — does it use `for`, `while`, or recursion?
  - `uses_globals` — does it reference variables not passed as params?

---

## Output Format

Write `knowledge/altpfe-model-inventory.json` — one object per model:

```json
[
  {
    "model_name": "FX_VANILLA",
    "asset_class": "FX",
    "java_orchestrator": "com.bank.altpfe.fx.FxVanillaProcess",
    "js_file": "models/fx/fx_vanilla.js",
    "js_lines": 42,
    "complexity": "simple",
    "datasets": {
      "trades": {
        "tds_method": "TDS.load",
        "filters": { "asset_class": "FX", "trade_type": "VANILLA" },
        "pre_processing": "none"
      },
      "assets": {
        "tds_method": "TDS.load",
        "filters": {},
        "pre_processing": "none"
      },
      "risk_factors": {
        "tds_method": "TDS.load",
        "filters": { "curve_type": "FX_SPOT" },
        "pre_processing": "none"
      }
    },
    "join_chain": [
      {
        "step": 1,
        "left": "trades",
        "right": "assets",
        "tds_method": "TDS.join",
        "sql_equivalent": "INNER JOIN",
        "keys": ["asset_id"],
        "output_alias": "trades_assets"
      },
      {
        "step": 2,
        "left": "trades_assets",
        "right": "risk_factors",
        "tds_method": "TDS.leftJoin",
        "sql_equivalent": "LEFT JOIN",
        "keys": ["currency_pair", "curve_date"],
        "output_alias": "joined"
      }
    ],
    "js_invocation": {
      "params": [
        { "name": "notional",       "source_column": "trade_notional",  "type": "double" },
        { "name": "maturity_days",  "source_column": "days_to_maturity", "type": "int"    },
        { "name": "fx_spot_rate",   "source_column": "spot_rate",        "type": "double" }
      ],
      "return_type": "double",
      "return_column": "exposure"
    },
    "js_description": "Calculates PFE for vanilla FX forwards using parametric volatility scaling. Applies a square-root-of-time decay to notional scaled by spot rate. Handles zero-rate edge case by returning zero exposure.",
    "complexity_flags": {
      "dynamic_eval":    false,
      "external_calls":  false,
      "date_arithmetic": true,
      "if_count":        2,
      "has_loops":       false,
      "uses_globals":    false
    },
    "migration_notes": ""
  }
]
```

**Complexity rules** — assign one of: `simple`, `medium`, `complex`

| Label | Criteria |
|-------|---------|
| `simple` | `js_lines` < 50 AND `if_count` ≤ 3 AND no `dynamic_eval` AND no `external_calls` |
| `medium` | `js_lines` 50–150 OR `if_count` 4–10 OR `date_arithmetic` with complex logic |
| `complex` | `js_lines` > 150 OR `dynamic_eval` OR `external_calls` OR `uses_globals` |

---

## Completion Checklist

- [ ] Exactly 35 entries in the JSON array
- [ ] Every entry has `java_orchestrator`, `js_file`, `join_chain`, `js_invocation`
- [ ] Every entry has `complexity` assigned
- [ ] `js_description` is 3–5 sentences for every model
- [ ] All `[ESCALATE]` flags noted in `migration_notes` field
- [ ] File saved to `knowledge/altpfe-model-inventory.json`

**Report:**
```
Agent 02 complete.
  Output: knowledge/altpfe-model-inventory.json
  Models inventoried: 35
  Simple: [N]  Medium: [N]  Complex: [N]
  Models with [ESCALATE] flags: [N] — list them
```
