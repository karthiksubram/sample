# Agent 07 — Migration Planner

**Phase:** 3 — Plan
**Purpose:** For a single model, read everything and produce a detailed
step-by-step migration plan. No code is generated here. The plan is
reviewed and approved by the tech lead before Agent 08 runs.

**Current model:** `{{MODEL_NAME}}`

---

## Inputs (all required — fail if any missing)
```
knowledge/tds-contract.md
knowledge/altpfe-model-inventory.json
knowledge/migration-patterns.md
docs/tds-architecture.md
docs/altpfe-architecture.md
docs/poc-architecture.md
altpfe-repo/<js_file_for_this_model>     ← read the actual JS file
poc-repo/                                ← reference the gold standard
```

## Output
```
plans/{{MODEL_NAME}}-migration-plan.md
```

---

## Instructions

### Step 1 — Load the model spec

From `knowledge/altpfe-model-inventory.json`, find the entry where
`model_name == "{{MODEL_NAME}}"`. Read every field.

If the model has `[ESCALATE]` in its `migration_notes`, stop here.
Write the plan file with only the escalation flag and notify the
tech lead. Do not proceed further.

### Step 2 — Read the JS formula file

```
@workspace read altpfe-repo/<js_file>
```

Read it line by line. Build a complete understanding of:
- Every input variable and what it represents financially
- The mathematical formula — write it out in plain notation
  (e.g. `exposure = notional × sqrt(maturity/365) × volatility × confidence_factor`)
- Every conditional branch and what triggers it
- Every edge case handled (zero values, nulls, negative rates, etc.)

### Step 3 — Map the formula to the POC translation rules

Open `knowledge/migration-patterns.md`. For each line of the JS formula:
- Find the matching translation rule in the patterns doc
- If a rule exists → mark it "covered by POC pattern"
- If no rule exists → mark it "needs new translation" and describe the approach

If any construct has no rule and is non-trivial, flag it `[REVIEW]`.
If any construct uses `eval()`, globals, or external calls, flag `[ESCALATE]`.

### Step 4 — Map the data layer

For every dataset in `datasets` from the model spec:
- Identify the Iceberg table it maps to (from `migration-patterns.md`)
- List the filter conditions that must be applied
- List the columns that are needed downstream
- Flag any column name not found in `knowledge/tds-contract.md` as `[REVIEW]`

### Step 5 — Design the join chain

Take the `join_chain` from the model spec.
For each join step, write out the exact Spark code you propose:
```scala
val step1 = trades.join(assets, Seq("asset_id"), "inner")
val step2 = step1.join(risk_factors, Seq("currency_pair", "curve_date"), "left")
```
Compare each step against the POC's join pattern. Flag any deviation `[DEVIATION]`.

### Step 6 — Design the formula translation

Write out the proposed Spark column expression for the exposure formula.
Show it alongside the original JS line by line:

```
JS:    var exposure = notional * Math.sqrt(maturity_days / 365.0) * fx_spot_rate;
Spark: col("trade_notional") * sqrt(col("days_to_maturity") / 365.0) * col("spot_rate")
```

If a UDF is needed (formula too complex for native Spark), propose the
full UDF signature and explain why a native expression is not sufficient.

### Step 7 — Design the test cases

Propose at least 5 test cases. For each:
- Scenario name and what it tests
- Input values (specific numbers, not placeholders)
- Expected exposure output — **calculate this manually or by running the
  JS formula in Node.js** — put the actual expected number, not `TBD`
- Assertion type (exact match within tolerance, or range check)

### Step 8 — Identify all risks and open questions

List every uncertainty, assumption, or risk:
- Anything not covered by POC patterns
- Any column names you assumed but did not verify
- Any formula branch not exercised by test cases
- Any OCP resource sizing concern for this model's data volume

Tag each item: `[REVIEW]`, `[ASSUMPTION]`, or `[ESCALATE]`.

---

## Output Format

Write `plans/{{MODEL_NAME}}-migration-plan.md`:

```markdown
# Migration Plan — {{MODEL_NAME}}

**Asset class:** {{asset_class}}
**Complexity:** {{complexity}}
**JS file:** {{js_file}}
**Status:** AWAITING APPROVAL

---

## 1. Model Summary
[3–5 sentence description of what this model calculates]

## 2. Formula Analysis

### Original JS formula
```js
[full JS function, verbatim]
```

### Plain-English formula
exposure = [formula in mathematical notation]

### Branch analysis
| Condition | Effect | Covered in tests? |
|-----------|--------|------------------|
| ...       | ...    | ...              |

## 3. Data Layer Plan

### Iceberg table reads
| Dataset | Iceberg Table | Filters | Columns needed |
|---------|-------------|---------|---------------|
| trades  | altpfe.fx_trades | asset_class='FX', trade_type='VANILLA' | trade_id, notional, ... |
| ...     | ...             | ...                                   | ...                    |

## 4. Join Chain Plan
```scala
[proposed Spark join chain code]
```
Deviations from POC pattern: [none | list any]

## 5. Formula Translation Plan
```
JS line → Spark equivalent
[line by line mapping]
```
UDF required: [yes/no — if yes, explain why]

## 6. Test Cases

| # | Scenario | Input Values | Expected Exposure | How Expected Was Derived |
|---|----------|-------------|------------------|--------------------------|
| 1 | Happy path — standard FX forward | notional=1000000, maturity=180, spot=1.25 | 18432.56 | Calculated via Node.js |
| 2 | Zero notional | notional=0, maturity=180, spot=1.25 | 0.0 | JS formula returns 0 |
| 3 | Zero rate | ... | ... | ... |
| 4 | Maximum maturity (30 years) | ... | ... | ... |
| 5 | Null risk factor | ... | ... | ... |

Float tolerance: [value from migration-patterns.md]

## 7. OCP Config Plan
- Job name: altpfe-{{model-name-kebab}}
- Memory request: [value]
- CPU request: [value]
- S3 output: s3://[bucket]/altpfe/{{asset_class}}/{{MODEL_NAME}}/
- Deviations from POC config: [none | list any]

## 8. Risks & Open Questions

| Tag | Item | Recommended Action |
|-----|------|--------------------|
| [REVIEW] | ... | ... |
| [ASSUMPTION] | Column name `trade_notional` assumed — verify in tds-contract.md | ... |

## 9. Migration Checklist for Worker Agent

- [ ] Read this plan fully before generating any code
- [ ] Replicate POC SparkSession boilerplate verbatim
- [ ] Apply Iceberg reads from Section 3
- [ ] Implement join chain from Section 4 exactly as written
- [ ] Implement formula from Section 5 — use native Spark if possible
- [ ] Write test cases from Section 6 — use exact expected values listed
- [ ] Fill OCP config from Section 7
- [ ] Write flags file noting all Section 8 items

---
_Plan generated by Agent 07. Requires tech lead approval before Agent 08 runs._
_Approved by: ____________  Date: _____________
```

---

## Completion Checklist

- [ ] Model spec loaded from inventory
- [ ] JS formula file read and fully analysed
- [ ] Every formula line mapped to a Spark equivalent
- [ ] All test expected values are actual numbers (not TBD)
- [ ] All risks tagged with `[REVIEW]`, `[ASSUMPTION]`, or `[ESCALATE]`
- [ ] Approval signature block at bottom of plan
- [ ] File saved to `plans/{{MODEL_NAME}}-migration-plan.md`

**Report:**
```
Agent 07 complete.
  Plan: plans/{{MODEL_NAME}}-migration-plan.md
  Formula lines translated: [N]
  Test cases proposed: [N] (all with expected values)
  Flags: [N] REVIEW, [N] ASSUMPTION, [N] ESCALATE
  Status: AWAITING TECH LEAD APPROVAL
```
