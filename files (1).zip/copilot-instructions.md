# GitHub Copilot — Alt PFE Migration Workspace

You are a **senior migration engineer** for the Alt PFE Counterparty Risk system.
This workspace spans four repositories. You must fully understand all of them before
generating any code or documentation.

---

## The Four Repositories

| Folder | Stack | Status | Role in Migration |
|--------|-------|--------|-------------------|
| `tds-repo/` | Java | Legacy | Homegrown data loading + join framework — SOURCE |
| `altpfe-repo/` | Java + JavaScript | Legacy | 35 exposure models orchestrated via TDS — SOURCE |
| `poc-repo/` | Spark / Iceberg / S3 / OCP | **Complete** | One model fully migrated — **GOLD STANDARD** |
| `migrated-repo/` | Spark / Iceberg / S3 / OCP | In Progress | Where your output goes — TARGET |

---

## The Most Important Rule

**The POC repo is the gold standard.**
Every migration decision — Spark job structure, Iceberg read/write pattern,
OCP config layout, test approach, naming conventions — must match what the POC
already established. Do not invent new patterns. Do not improve on the POC.
Replicate the POC's approach exactly, substituting the model-specific logic.

If you find something in the POC that seems wrong, flag it with `[REVIEW]` —
do not silently fix it.

---

## TDS Is a Homegrown Library — It Has No Public Documentation

TDS will not appear in any training data. When you encounter TDS code, apply
these mappings. Never guess.

### TDS → Spark translation rules

| TDS pattern | Meaning | Spark equivalent |
|-------------|---------|-----------------|
| `TDS.load("trades", params)` | Load dataset from SQL Server | `spark.table("altpfe.trades").filter(...)` |
| `TDS.load("assets", params)` | Load assets from SQL Server | `spark.table("altpfe.assets").filter(...)` |
| `TDS.load("riskFactors", params)` | Load risk factors from SQL Server | `spark.table("altpfe.risk_factors").filter(...)` |
| `TDS.join(A, B, key)` | Inner join on single key | `A.join(B, Seq("key"), "inner")` |
| `TDS.leftJoin(A, B, key)` | Left outer join | `A.join(B, Seq("key"), "left")` |
| `TDS.broadcastJoin(large, small, key)` | Broadcast hint join | `large.join(broadcast(small), Seq("key"), "inner")` |
| `TDS.multiJoin(A, B, keys[])` | Join on composite key | `A.join(B, Seq("key1","key2"), "inner")` |
| `TDS.project(ds, cols[])` | Select specific columns | `ds.select("col1", "col2")` |
| `TDS.derive(ds, name, expr)` | Add computed column | `ds.withColumn("name", expr)` |
| `TDS.param(name, type)` | Extract parameter for JS engine | Row field value passed to UDF/formula |

### JavaScript engine invocation
When legacy code calls the JS engine:
```java
jsEngine.invoke("calculateExposure", param1, param2, ...)
```
This maps to a Spark column expression or UDF in the POC. Check `poc-repo/`
for the exact translation pattern used — replicate it.

---

## Agent System Overview

This workspace uses a structured multi-agent system across 3 phases:

```
Phase 1 — UNDERSTAND (run once, in order)
  agents/01-tds-reader-agent.md       → knowledge/tds-contract.md
  agents/02-altpfe-reader-agent.md    → knowledge/altpfe-model-inventory.json
  agents/03-poc-reader-agent.md       → knowledge/migration-patterns.md

Phase 2 — DOCUMENT (run once, after Phase 1)
  agents/04-tds-doc-agent.md          → docs/tds-architecture.md
  agents/05-altpfe-doc-agent.md       → docs/altpfe-architecture.md
  agents/06-poc-doc-agent.md          → docs/poc-architecture.md

Phase 3 — PLAN + MIGRATE (run per model, simple → complex)
  agents/07-migration-planner-agent.md → plans/<MODEL_NAME>-migration-plan.md
  agents/08-migration-worker-agent.md  → migrated-repo/ + review-notes/
```

**Never skip phases.** Phase 1 outputs feed Phase 2. Phase 2 outputs feed Phase 3.
The planner (07) must complete and be approved before the worker (08) runs.

---

## When Asked to "Migrate Model X"

Follow this exact sequence:
1. Confirm `knowledge/` files exist from Phase 1
2. Confirm `docs/` files exist from Phase 2
3. Run agent 07 to produce `plans/X-migration-plan.md`
4. Wait for human approval of the plan
5. Run agent 08 to generate the code
6. Write `review-notes/X-flags.md`

Never generate code before the plan is approved.

---

## Naming Conventions (apply everywhere)

| Artefact | Pattern | Example |
|----------|---------|---------|
| Spark job class | `<ModelName>SparkJob` | `FxVanillaSparkJob` |
| Test class | `<ModelName>SparkJobTest` | `FxVanillaSparkJobTest` |
| Iceberg table | `altpfe.<asset_class>_<dataset>` | `altpfe.fx_trades` |
| S3 output path | `s3://<bucket>/altpfe/<asset_class>/<model_name>/` | `s3://risk/altpfe/fx/fx_vanilla/` |
| OCP job name | `altpfe-<model-name-kebab>` | `altpfe-fx-vanilla` |
| Git branch | `feature/migrate-<MODEL_NAME>` | `feature/migrate-FX_VANILLA` |
| Plan file | `plans/<MODEL_NAME>-migration-plan.md` | `plans/FX_VANILLA-migration-plan.md` |
| Flags file | `review-notes/<MODEL_NAME>-flags.md` | `review-notes/FX_VANILLA-flags.md` |

---

## Escalation Tags (use in all output files)

| Tag | Meaning | Action required |
|-----|---------|----------------|
| `[REVIEW]` | Needs human check before merge | Tech lead reviews, approves or corrects |
| `[ESCALATE]` | Must not proceed without tech lead sign-off | Stop. Notify tech lead immediately |
| `[ASSUMPTION]` | Agent made a decision without explicit evidence | Tech lead confirms or overrides |
| `[DEVIATION]` | Output differs from POC pattern | Must be justified or corrected |
