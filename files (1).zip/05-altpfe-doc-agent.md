# Agent 05 — Alt PFE Architecture Doc

**Phase:** 2 — Document
**Purpose:** Produce a human-readable architecture document for the entire
Alt PFE legacy system — the 35 models, the Java orchestration layer,
the JavaScript formulas, and how they are scheduled and executed.

---

## Inputs
```
altpfe-repo/                              ← read-only
knowledge/tds-contract.md                 ← must exist
knowledge/altpfe-model-inventory.json     ← must exist (run Agent 02 first)
```

## Output
```
docs/altpfe-architecture.md
```

---

## Audience

Same as Agent 04 — developers, tech leads, and future maintainers.
A reader should finish this document fully understanding what Alt PFE
does, how it is structured, and what the 35 models are.

---

## Instructions

### Section 1 — System Purpose

Write 2–3 paragraphs explaining:
- What "Alternate Potential Future Exposure" means in business terms
- Why this system exists alongside the main PFE system
- What the output (exposure numbers) is used for downstream

### Section 2 — System Architecture Overview

Draw an ASCII or Mermaid diagram of the end-to-end flow:
```
Autosys scheduler
  → Java process (asset class specific)
    → TDS: load Trades + Assets + Risk Factors from SQL Server
      → TDS: join datasets
        → JavaScript engine: calculate exposure
          → write results
```

Label each step with the technology involved.

### Section 3 — The 35 Models

Produce a summary table of all 35 models from
`knowledge/altpfe-model-inventory.json`:

| # | Model Name | Asset Class | Complexity | JS Lines | Key Datasets | Brief Description |
|---|-----------|-------------|-----------|---------|-------------|-------------------|
| 1 | FX_VANILLA | FX | simple | 42 | trades, assets, risk_factors | ... |
| ... |

Then group the models by asset class and write a short paragraph
for each asset class group explaining what the models in that group
compute and what makes them different from each other.

### Section 4 — Java Orchestration Layer

Explain how the Java code works:
- Class hierarchy (base class → asset-class-specific → model-specific)
- How an Autosys job triggers a specific model
- How the Java class selects the right JS file
- How parameters flow from the joined dataset to the JS invocation
- Error handling and logging patterns

### Section 5 — The JavaScript Formulas

Explain the JS layer:
- Why JavaScript was chosen for the formulas
- How the JS engine is embedded in Java (Nashorn? Rhino? ScriptEngine API?)
- How a JS formula is structured (standard function signature?)
- The range of formula complexity across the 35 models
- What kinds of financial calculations appear in the formulas

### Section 6 — Data Flow for One Model (Worked Example)

Walk through the complete data flow for the simplest FX model step by step:
1. Autosys triggers the job with parameters (date, asset class)
2. Java class initialises and calls TDS to load Trades
3. TDS executes SQL on SQL Server — show the query pattern
4. Repeat for Assets and Risk Factors
5. TDS joins the datasets — show the join chain
6. Java extracts parameters from the joined row
7. JS engine executes the formula — show input values and output
8. Result is written

### Section 7 — Known Limitations of the Legacy System

List the constraints and pain points in the current system.
These are the reasons the migration is happening:
- Single-threaded JS execution
- SQL Server as the data source (scaling, cost)
- TDS being homegrown with no community support
- Any known data quality issues
- Any known formula bugs or workarounds in the JS files

### Section 8 — What Is NOT Changing

Clarify what is preserved in the migration:
- The financial formula logic (JS formulas are translated, not replaced)
- The model inventory (same 35 models)
- The output schema (exposure numbers per trade)
- The scheduling trigger (Autosys → OCP Jobs)

---

## Output Format

Write `docs/altpfe-architecture.md`. Include the full model summary table.
Use code snippets from actual source files to illustrate key points.

---

## Completion Checklist

- [ ] System purpose explained in business terms
- [ ] End-to-end architecture diagram included
- [ ] All 35 models listed in summary table
- [ ] Models grouped and described by asset class
- [ ] Java orchestration layer explained
- [ ] JS engine and formula layer explained
- [ ] Worked example walks through one complete model
- [ ] Known limitations documented
- [ ] What is NOT changing documented
- [ ] File saved to `docs/altpfe-architecture.md`

**Report:**
```
Agent 05 complete.
  Output: docs/altpfe-architecture.md
  Models documented: 35
  Asset class groups: [N]
```
