#!/usr/bin/env bash
# run-all-migrations.sh
# Runs Phase 3 (plan + migrate) for all approved or pending models.
# Respects phase gates — will not run if Phase 1 or 2 are incomplete.
#
# Usage:
#   ./scripts/run-all-migrations.sh              # migrate all pending
#   ./scripts/run-all-migrations.sh --dry-run    # show order, no execution
#   ./scripts/run-all-migrations.sh --model FX_VANILLA        # one model
#   ./scripts/run-all-migrations.sh --plan-only  # run planners only, no workers

set -euo pipefail

DRY_RUN=false
TARGET_MODEL=""
PLAN_ONLY=false

while [[ $# -gt 0 ]]; do
  case $1 in
    --dry-run)    DRY_RUN=true; shift ;;
    --model)      TARGET_MODEL="$2"; shift 2 ;;
    --plan-only)  PLAN_ONLY=true; shift ;;
    *) echo "Unknown argument: $1"; exit 1 ;;
  esac
done

INVENTORY="knowledge/altpfe-model-inventory.json"
STATE="migration-state.json"

# ── Phase gates ────────────────────────────────────────────────────────────────

phase1_ok=$(jq -r '.phase1_complete' "$STATE")
phase2_ok=$(jq -r '.phase2_complete' "$STATE")

if [[ "$phase1_ok" != "true" ]]; then
  echo "ERROR: Phase 1 not complete."
  echo "       Run agents 01, 02, 03 first, then set phase1_complete=true in $STATE"
  exit 1
fi

if [[ "$phase2_ok" != "true" ]]; then
  echo "ERROR: Phase 2 not complete."
  echo "       Run agents 04, 05, 06 first and review docs/, then set phase2_complete=true"
  exit 1
fi

if [[ ! -f "$INVENTORY" ]]; then
  echo "ERROR: $INVENTORY not found."
  exit 1
fi

# ── Build ordered model list (simple → medium → complex) ──────────────────────

MODELS=$(jq -r '
  sort_by(
    if .complexity == "simple"  then 0
    elif .complexity == "medium" then 1
    else 2
    end
  ) | .[].model_name' "$INVENTORY")

PLAN_OK=0; PLAN_FAIL=0
MIGRATE_OK=0; MIGRATE_FAIL=0; MIGRATE_SKIP=0

# ── Main loop ──────────────────────────────────────────────────────────────────

for MODEL in $MODELS; do

  [[ -n "$TARGET_MODEL" && "$TARGET_MODEL" != "$MODEL" ]] && continue

  STATUS=$(jq -r --arg m "$MODEL" '.models[$m].status // "pending"' "$STATE" 2>/dev/null || echo "pending")
  COMPLEXITY=$(jq -r --arg m "$MODEL" \
    '.[] | select(.model_name == $m) | .complexity' "$INVENTORY")
  ESCALATED=$(jq -r --arg m "$MODEL" \
    '.[] | select(.model_name == $m) | .migration_notes' "$INVENTORY" \
    | grep -c '\[ESCALATE\]' || true)

  echo ""
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "  Model: $MODEL  ($COMPLEXITY)"
  echo "  Status: $STATUS"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  # Skip escalated models
  if [[ "$ESCALATED" -gt 0 ]]; then
    echo "  ⛔  ESCALATED — skipping. Tech lead review required."
    echo "      See knowledge/altpfe-model-inventory.json migration_notes for $MODEL"
    ((MIGRATE_SKIP++)) || true
    continue
  fi

  # Skip already migrated
  if [[ "$STATUS" == "migrated" ]]; then
    echo "  ⏭   Already migrated — skipping."
    ((MIGRATE_SKIP++)) || true
    continue
  fi

  # ── Step A: Run planner if plan not yet ready ────────────────────────────────
  PLAN_FILE="plans/${MODEL}-migration-plan.md"

  if [[ ! -f "$PLAN_FILE" ]]; then
    echo "  📋  Running planner (Agent 07)..."
    _update_state "$MODEL" "plan_in_progress"

    if [[ "$DRY_RUN" == "true" ]]; then
      echo "  [DRY RUN] copilot-agent run agents/07-migration-planner-agent.md --var MODEL_NAME=$MODEL"
    else
      if copilot-agent run agents/07-migration-planner-agent.md --var MODEL_NAME="$MODEL"; then
        _update_state "$MODEL" "plan_ready"
        echo "  ✅  Plan ready: $PLAN_FILE"
        echo "      → Open the plan, review it, add approval signature, then re-run."
        ((PLAN_OK++)) || true
      else
        _update_state "$MODEL" "plan_failed"
        echo "  ❌  Planner failed for $MODEL"
        ((PLAN_FAIL++)) || true
      fi
    fi
    continue  # Always pause after plan — require human approval
  fi

  # ── Step B: Check plan approval ──────────────────────────────────────────────
  APPROVED=$(grep -c "Approved by:.\S" "$PLAN_FILE" || true)

  if [[ "$APPROVED" -eq 0 ]]; then
    echo "  ⏸   Plan exists but NOT approved."
    echo "      Open $PLAN_FILE, review, sign the approval line, then re-run."
    ((MIGRATE_SKIP++)) || true
    continue
  fi

  if [[ "$PLAN_ONLY" == "true" ]]; then
    echo "  ℹ️   --plan-only mode: skipping worker for $MODEL"
    continue
  fi

  # ── Step C: Run migration worker ─────────────────────────────────────────────
  echo "  🔨  Running migration worker (Agent 08)..."
  _update_state "$MODEL" "migrating"

  if [[ "$DRY_RUN" == "true" ]]; then
    echo "  [DRY RUN] copilot-agent run agents/08-migration-worker-agent.md --var MODEL_NAME=$MODEL"
    continue
  fi

  if copilot-agent run agents/08-migration-worker-agent.md --var MODEL_NAME="$MODEL"; then
    _update_state "$MODEL" "migrated"
    echo "  ✅  Migrated: $MODEL"
    ((MIGRATE_OK++)) || true
  else
    _update_state "$MODEL" "needs_review"
    echo "  ⚠️   Worker flagged issues for $MODEL"
    echo "      See review-notes/${MODEL}-flags.md"
    ((MIGRATE_FAIL++)) || true
  fi

done

# ── Summary ────────────────────────────────────────────────────────────────────

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  Run complete."
echo ""
echo "  Plans generated:    $PLAN_OK  (failed: $PLAN_FAIL)"
echo "  Models migrated:    $MIGRATE_OK"
echo "  Needs review:       $MIGRATE_FAIL"
echo "  Skipped:            $MIGRATE_SKIP"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

# ── Helper ─────────────────────────────────────────────────────────────────────

_update_state() {
  local model="$1"
  local status="$2"
  local now
  now=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  jq --arg m "$model" --arg s "$status" --arg t "$now" \
    '.models[$m].status = $s | .last_updated = $t' \
    "$STATE" > /tmp/_state.json && mv /tmp/_state.json "$STATE"
}
