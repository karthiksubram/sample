# Agent 04 — TDS Architecture Doc

**Phase:** 2 — Document
**Purpose:** Produce a human-readable architecture document for the TDS
library. Written for developers who need to understand the legacy system
but may never have seen the TDS source code.

---

## Inputs
```
tds-repo/                      ← read-only
knowledge/tds-contract.md      ← must exist (run Agent 01 first)
```

## Output
```
docs/tds-architecture.md
```

---

## Audience

This document is for:
- Developers joining the migration who need to understand what they are replacing
- Tech leads reviewing migration decisions
- Future maintainers who need to understand why certain Spark patterns were chosen

Write clearly. Avoid jargon where possible. Use diagrams in ASCII or
Mermaid where they aid understanding.

---

## Instructions

Read `tds-repo/` and `knowledge/tds-contract.md` together.
Produce a document covering all sections below.

### Section 1 — What is TDS?

Write a 2–3 paragraph plain-English description of TDS:
- What problem it was built to solve
- How it fits into the Alt PFE system
- What it does and does not do (scope and limitations)

### Section 2 — Architecture Overview

Draw an ASCII or Mermaid flow diagram showing:
```
SQL Server → TDS Loader → TDS Dataset → TDS Join Engine → Joined Dataset → JS Engine
```
Label each arrow with what flows across it (SQL query, row data, parameters, etc.)

### Section 3 — Dataset Loading

Explain how TDS loads data from SQL Server:
- Connection mechanism
- How queries are constructed (parameterised? stored proc?)
- The three core datasets (Trades, Assets, Risk Factors):
  - What each one contains (business meaning, not just column names)
  - What filter parameters narrow each dataset
  - Column list with business meaning for each column
- Any quirks in how SQL Server data is typed or encoded that TDS handles

### Section 4 — The Join Engine

Explain TDS joins in plain English:
- Why TDS has its own join layer (instead of SQL joins)
- How each join type works
- Walk through a concrete example of a 2-step join chain
  (use trades → assets → risk_factors as the example)
- Known edge cases or limitations

### Section 5 — JavaScript Engine Integration

Explain how TDS feeds the JS engine:
- How a joined dataset row becomes JS function parameters
- Type mapping from Java/TDS to JavaScript
- How the JS return value flows back into the Java process
- Performance characteristics (single-threaded? row-by-row?)

### Section 6 — What TDS Does NOT Do

List explicitly what TDS cannot do — things that required workarounds
in the Alt PFE code, or things that are handled outside TDS.
This helps migration engineers understand where custom logic lives.

### Section 7 — TDS → Spark Migration Mapping

A quick-reference table for migration engineers:

| TDS Concept | Spark Equivalent | Notes |
|-------------|-----------------|-------|
| Dataset | DataFrame | ... |
| TDS.load() | spark.table() | ... |
| TDS.join() | .join("inner") | ... |
| ... | ... | ... |

---

## Output Format

Write `docs/tds-architecture.md`. Use clear markdown headings.
Include code examples from the actual TDS source to illustrate each concept.

---

## Completion Checklist

- [ ] Plain-English description of TDS written
- [ ] Architecture flow diagram included
- [ ] All three core datasets described with business meaning
- [ ] Join engine explained with worked example
- [ ] JS engine integration explained
- [ ] "What TDS does NOT do" section written
- [ ] Migration mapping table complete
- [ ] File saved to `docs/tds-architecture.md`

**Report:**
```
Agent 04 complete.
  Output: docs/tds-architecture.md
```
