# Agent 06 — POC Architecture Doc

**Phase:** 2 — Document
**Purpose:** Produce a human-readable architecture document for the POC
(new stack). This document explains what was built, every decision made,
and why — so the full team understands the target architecture before
migration begins at scale.

---

## Inputs
```
poc-repo/                          ← read-only
knowledge/migration-patterns.md   ← must exist (run Agent 03 first)
```

## Output
```
docs/poc-architecture.md
```

---

## Audience

Developers who will be working on the 34 remaining model migrations.
A reader should finish this document knowing exactly what the target
system looks like and why it is built the way it is.

---

## Instructions

### Section 1 — What the POC Proves

Write a short summary of:
- Which model was migrated in the POC
- What the POC demonstrates works end-to-end
- The confidence it gives us for the remaining 34 models

### Section 2 — New Stack Overview

Draw a diagram of the new system equivalent to the legacy diagram
in Agent 05:

```
OCP Job scheduler
  → Spark job (OCP Pod)
    → Read Trades + Assets + Risk Factors from Iceberg / S3
      → Spark DataFrame joins
        → Spark column expression / UDF: calculate exposure
          → Write results to Iceberg / S3
```

Label each component with the actual technology and version.

### Section 3 — Why Each Technology Was Chosen

For each technology in the new stack, write 2–4 sentences explaining
why it was chosen over alternatives:
- **Apache Spark** — vs. alternatives
- **Apache Iceberg** — vs. plain Parquet or Delta Lake
- **S3** — vs. SQL Server
- **OCP (OpenShift Container Platform)** — vs. bare Autosys

### Section 4 — Spark Job Structure

Explain the structure of a Spark job in the new system:
- SparkSession configuration — every config key and why it is set
- How Iceberg tables are read and what catalog is used
- How the join chain maps from TDS to Spark DataFrames
- How the JS formula was translated into Spark
- How results are written to Iceberg

Include the verbatim SparkSession block from the POC as a code example.

### Section 5 — Formula Translation Deep Dive

This is the most important section for migration engineers.
Walk through the formula translation for the POC model in detail:

1. Show the original JS function (from altpfe-repo)
2. Show the Spark equivalent (from poc-repo)
3. Explain each translation decision line by line:
   - How each JS input variable became a Spark column reference
   - How JS conditionals became `.when().otherwise()`
   - How any JS date arithmetic became Spark date functions
   - How null cases are handled

### Section 6 — Iceberg Table Design

Explain the Iceberg table structure:
- Database/namespace naming
- Table naming convention
- Schema for each core table (Trades, Assets, Risk Factors, Results)
- Partition strategy and why
- Any hidden partitioning used

### Section 7 — OCP Job Configuration

Explain the OCP Job:
- How it maps to the legacy Autosys job
- Resource requests and limits — CPU and memory — and how they were sized
- Environment variable injection (S3 paths, Iceberg catalog URL, run date)
- How the job is triggered (manual? cron? event-driven?)
- Container image strategy

### Section 8 — Testing Approach

Explain how correctness is verified:
- What the tests assert
- How expected values were derived (from running legacy JS? manual calculation?)
- Float tolerance and why that value was chosen
- What scenarios are covered

### Section 9 — What a Migration Engineer Needs to Do Per Model

Give a precise checklist — this is the bridge between the POC doc
and the per-model migration plan:

1. Read the model entry in `knowledge/altpfe-model-inventory.json`
2. Read the JS formula file from `altpfe-repo`
3. Map each JS parameter to its source column in the joined dataset
4. Translate the formula following rules in `knowledge/migration-patterns.md`
5. Fill in the Iceberg read template for this model's datasets and filters
6. Replicate the join chain as Spark `.join()` calls
7. Fill in the OCP config template
8. Write 5+ test cases and pre-compute expected values
9. Run the planner agent to produce the migration plan
10. Get tech lead approval, then run the worker agent

---

## Output Format

Write `docs/poc-architecture.md`. This document should be detailed
enough that a developer who has never seen the POC can build the
next model correctly from scratch.

---

## Completion Checklist

- [ ] POC scope and what it proves is described
- [ ] New stack architecture diagram included
- [ ] Technology choices justified
- [ ] Spark job structure explained with verbatim code examples
- [ ] Formula translation walkthrough complete (JS → Spark, line by line)
- [ ] Iceberg table design documented
- [ ] OCP job configuration explained
- [ ] Testing approach explained
- [ ] Per-model migration checklist written (9 steps)
- [ ] File saved to `docs/poc-architecture.md`

**Report:**
```
Agent 06 complete.
  Output: docs/poc-architecture.md
  POC model documented: [name]
  Translation rules illustrated: [N]
```
