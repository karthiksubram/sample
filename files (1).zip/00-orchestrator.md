# Orchestrator — Alt PFE Migration

## Purpose
Master coordination document. Controls phase gates, agent sequencing,
state tracking, and escalation. Read this before running any agent.

---

## Phase Overview

```
┌─────────────────────────────────────────────────────────┐
│  PHASE 1 — UNDERSTAND                                   │
│  Read all 3 repos. Build machine-readable knowledge.    │
│                                                         │
│  01-tds-reader-agent       → knowledge/tds-contract.md  │
│  02-altpfe-reader-agent    → knowledge/altpfe-model-    │
│                               inventory.json            │
│  03-poc-reader-agent       → knowledge/migration-       │
│                               patterns.md               │
└────────────────────┬────────────────────────────────────┘
                     │ GATE: all 3 knowledge files exist
                     ▼
┌─────────────────────────────────────────────────────────┐
│  PHASE 2 — DOCUMENT                                     │
│  Produce human-readable architecture docs for team.     │
│                                                         │
│  04-tds-doc-agent          → docs/tds-architecture.md   │
│  05-altpfe-doc-agent       → docs/altpfe-architecture.md│
│  06-poc-doc-agent          → docs/poc-architecture.md   │
└────────────────────┬────────────────────────────────────┘
                     │ GATE: all 3 docs exist
                     ▼
┌─────────────────────────────────────────────────────────┐
│  PHASE 3 — PLAN + MIGRATE  (loop × 34 models)          │
│                                                         │
│  07-migration-planner  → plans/<MODEL>-migration-plan.md│
│       ↓ human approves plan                             │
│  08-migration-worker   → migrated-repo/ + review-notes/ │
└─────────────────────────────────────────────────────────┘
```

---

## Phase 1 — Understand

Run agents in strict order. Each output feeds the next.

### Agent 01 — TDS Reader
```
Input:   tds-repo/  (read-only)
Output:  knowledge/tds-contract.md
Prompt:  @workspace Run agents/01-tds-reader-agent.md
```

### Agent 02 — Alt PFE Reader
```
Input:   altpfe-repo/  (read-only)
         knowledge/tds-contract.md  ← must exist first
Output:  knowledge/altpfe-model-inventory.json
Prompt:  @workspace Run agents/02-altpfe-reader-agent.md
```

### Agent 03 — POC Reader
```
Input:   poc-repo/  (read-only)
Output:  knowledge/migration-patterns.md
Prompt:  @workspace Run agents/03-poc-reader-agent.md
```

### Phase 1 Gate
```bash
# Verify before proceeding
ls -lh knowledge/tds-contract.md            # expect > 1KB
ls -lh knowledge/altpfe-model-inventory.json # expect 35 entries
ls -lh knowledge/migration-patterns.md       # expect > 2KB
```

---

## Phase 2 — Document

Run after Phase 1 gate passes. Agents read from `knowledge/` + repos.
Outputs are for humans — your team, stakeholders, future maintainers.

### Agent 04 — TDS Architecture Doc
```
Input:   tds-repo/ + knowledge/tds-contract.md
Output:  docs/tds-architecture.md
Prompt:  @workspace Run agents/04-tds-doc-agent.md
```

### Agent 05 — Alt PFE Architecture Doc
```
Input:   altpfe-repo/ + knowledge/altpfe-model-inventory.json
Output:  docs/altpfe-architecture.md
Prompt:  @workspace Run agents/05-altpfe-doc-agent.md
```

### Agent 06 — POC Architecture Doc
```
Input:   poc-repo/ + knowledge/migration-patterns.md
Output:  docs/poc-architecture.md
Prompt:  @workspace Run agents/06-poc-doc-agent.md
```

### Phase 2 Gate
```bash
ls -lh docs/tds-architecture.md
ls -lh docs/altpfe-architecture.md
ls -lh docs/poc-architecture.md
```
Review all three docs with your team before starting Phase 3.
Correct any misunderstandings in the knowledge files now — it is
far cheaper to fix them here than mid-migration.

---

## Phase 3 — Plan + Migrate

Run per model. Always planner first, worker second.
Process in complexity order: simple → medium → complex.

### Step A — Run the planner
```
Input:   knowledge/ (all 3 files)
         docs/ (all 3 files)
         altpfe-repo/<model_js_file>
         poc-repo/ (reference)
Output:  plans/<MODEL_NAME>-migration-plan.md
Prompt:  @workspace Run agents/07-migration-planner-agent.md for model <MODEL_NAME>
```

### Step B — Tech lead reviews the plan
Open `plans/<MODEL_NAME>-migration-plan.md`.
- Confirm dataset mapping is correct
- Confirm join order matches legacy behaviour
- Confirm formula translation approach
- Approve or add corrections as comments

Do not proceed to Step C until the plan is approved.

### Step C — Run the worker
```
Input:   plans/<MODEL_NAME>-migration-plan.md (approved)
         knowledge/migration-patterns.md
         poc-repo/ (gold standard reference)
Output:  migrated-repo/src/models/<MODEL_NAME>/
         migrated-repo/config/<model-name>-ocp.yaml
         review-notes/<MODEL_NAME>-flags.md
Prompt:  @workspace Run agents/08-migration-worker-agent.md for model <MODEL_NAME>
```

### Step D — Update state
```bash
jq --arg m "<MODEL_NAME>" --arg s "migrated" \
  '.models[$m].status = $s' migration-state.json \
  > /tmp/s.json && mv /tmp/s.json migration-state.json
```

---

## State Tracking

`migration-state.json` tracks every model. Update after each step.

```json
{
  "phase1_complete": false,
  "phase2_complete": false,
  "last_updated": "",
  "models": {
    "FX_VANILLA": {
      "status": "migrated",
      "complexity": "simple",
      "plan_approved": true,
      "pr": "feature/migrate-FX_VANILLA",
      "review_flags": 0,
      "escalation_flags": 0
    },
    "IR_SWAP": {
      "status": "plan_ready",
      "complexity": "medium",
      "plan_approved": false,
      "pr": null,
      "review_flags": null,
      "escalation_flags": null
    }
  }
}
```

Status progression:
```
pending → plan_in_progress → plan_ready → plan_approved → migrating → migrated
                                                                     ↘ needs_review
```

---

## Escalation Rules

| Trigger | Tag | Who acts |
|---------|-----|---------|
| JS uses `eval()` or `Function()` | `[ESCALATE]` | Tech lead — stop migration |
| JS calls external functions | `[ESCALATE]` | Tech lead — stop migration |
| Join key not in tds-contract.md | `[ESCALATE]` | Tech lead — verify mapping |
| Test output diverges > 0.0001 | `[ESCALATE]` | Tech lead — check formula |
| Agent deviates from POC pattern | `[DEVIATION]` | Tech lead — approve or revert |
| Agent made undocumented assumption | `[ASSUMPTION]` | Tech lead — confirm or correct |

---

## Branch & PR Conventions

```
Branch:   feature/migrate-<MODEL_NAME>
Commit:   chore(migration): migrate <MODEL_NAME> to Spark/Iceberg
PR title: [Migration] <MODEL_NAME> — <asset_class> (<complexity>)
PR body:  contents of review-notes/<MODEL_NAME>-flags.md
```

---

## Bulk Run (Phase 3 — after plans approved)

```bash
# Dry run — shows order without executing
./scripts/run-all-migrations.sh --dry-run

# Migrate all models with approved plans
./scripts/run-all-migrations.sh

# Migrate one specific model
./scripts/run-all-migrations.sh --model FX_VANILLA
```
