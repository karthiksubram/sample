#!/bin/bash

echo "Applying queues.yaml (enable gang scheduling)..."
oc apply -f queues.yaml
echo "Restarting YuniKorn scheduler..."
oc rollout restart deployment/yunikorn-scheduler -n yunikorn

echo "Applying gang-scheduling-wait-demo job with parallelism 1 (observe Pending)..."
oc apply -f gang-job.yaml

echo "Monitor pods with: oc get pods -w"
echo "To increase parallelism, edit gang-job.yaml and oc apply again with parallelism: 2, 3, 4"
