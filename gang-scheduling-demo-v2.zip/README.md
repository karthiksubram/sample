# YuniKorn Gang Scheduling POC (with Partial Hog)

## Purpose

Demonstrate YuniKorn Gang Scheduling behavior:
- YuniKorn will WAIT until `minMember` pods can be scheduled together
- Gang will stay Pending if cluster resources are not enough
- Gang will schedule together when resources are freed

## Files

- `queues.yaml` — enables gang scheduling
- `gang-job.yaml` — defines Gang with `minMember=4`
- `hog-job.yaml` — consumes ~75% resources (partial hog)
- `deploy-gang-demo.sh` — deploys queues and Gang job

## Steps

### 1️⃣ Enable Gang Scheduling

```bash
oc apply -f queues.yaml
oc rollout restart deployment/yunikorn-scheduler -n yunikorn
```

### 2️⃣ Start Hog Job (consume resources)

```bash
oc apply -f hog-job.yaml
oc get pods -w  # Wait for hog pods to start Running
```

### 3️⃣ Start Gang Job

```bash
oc apply -f gang-job.yaml
oc get pods -w
```

**Expected:** Gang placeholders will be created → pods will stay Pending → YuniKorn is waiting.

### 4️⃣ Free resources

```bash
oc delete job hog-job
```

**Expected:** Gang placeholders will now get resources → Gang pods will start Running together.

## Notes

- If you fully block the cluster → K8s will reject new pod creation. Use **partial hog** only.
- The Gang Job uses TaskGroup API → per YuniKorn official guide.

## Reference

https://yunikorn.apache.org/docs/user_guide/gang_scheduling/
